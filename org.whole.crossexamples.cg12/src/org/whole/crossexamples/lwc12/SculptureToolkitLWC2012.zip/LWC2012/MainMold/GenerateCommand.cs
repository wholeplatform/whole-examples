namespace MainMold
{
    using System.Linq;    
    using System.Windows;
    using System.Windows.Controls;
    using Modelingsoft.Sculpture.SModel.Common;
    using Modelingsoft.Sculpture.SDesign.Common;

    [MoldComponent(typeof(ISDesignToolBarCommand), MainMold.MoldName, MainMold.ModelName)]
    public class GenerateCommand : SDesignToolBarCommand
    {
        public override int Order
        {
            get { return 10; }
        }

        public override FrameworkElement GetNewVisualElement()
        {
            // return any control as the follwong example:
            Button button = new Button();
            button.Content = "Generate Web Document";
            button.Click += new RoutedEventHandler(Command_Click);
            return button;
        }

        private void Command_Click(object sender, RoutedEventArgs e)
        {
            if (this.DomainModel.IsValid)
            {
                this.SculptureGenerator.GenerateAsync(this.DomainModel, true, true);
            }
        }
    }
}