namespace LWC2012.Model
{
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    public partial class LWC2012Serializer : LWC2012SerializerBase
    {
        #region Constructors
        
        private LWC2012Serializer()
        {
        }
        
        #endregion
        
        #region Public Static Methods
        
        public static CommonModel::IDomainSerializer CreateNewInstance()
        {
            return new LWC2012Serializer(); 
        }
        
        #endregion
    }

    public abstract class LWC2012SerializerBase : CommonModel::DomainSerializer
    {    
        #region Private Variables

        private global::System.Collections.Generic.List<global::System.Exception> exceptions = new global::System.Collections.Generic.List<global::System.Exception>();

        #endregion       
        
        #region Public Override Methods

        public override global::System.Collections.Generic.IEnumerable<global::System.Exception> ValidateXmlByXsd(global::System.String xmlPath)
        {
            global::System.Reflection.Assembly assembly = typeof(LWC2012SerializerBase).Assembly;
            string[] manifestResourceNames = assembly.GetManifestResourceNames();
            string schemaName = null;

            foreach (string name in manifestResourceNames)
            {
                if (true == name.Contains("ModelSchema.xsd"))
                {
                    schemaName = name;
                    break; 
                }
            }

            global::System.IO.Stream stream = assembly.GetManifestResourceStream(schemaName);
            global::System.Xml.Schema.XmlSchema xmlSchema = global::System.Xml.Schema.XmlSchema.Read(stream, null);            
            global::System.Xml.Schema.XmlSchemaSet schemaSet = new global::System.Xml.Schema.XmlSchemaSet();
            schemaSet.Add(xmlSchema);
            global::System.Xml.XmlReaderSettings settings = new global::System.Xml.XmlReaderSettings();
            settings.Schemas = schemaSet;
            settings.ValidationType = global::System.Xml.ValidationType.Schema;
            settings.ValidationEventHandler += new System.Xml.Schema.ValidationEventHandler(this.Settings_ValidationEventHandler); 
            try
            {
                using (global::System.Xml.XmlReader reader = global::System.Xml.XmlReader.Create(xmlPath, settings))
                {
                    while (true == reader.Read())
                    {
                    }
                }
            }
            catch (global::System.Xml.XmlException ex)
            {
                this.exceptions.Add(ex);
            }
            catch (global::System.Exception ex)
            {
                this.exceptions.Add(ex);
            }
            
            return this.exceptions;
        }

        #endregion
        
        #region Protected/Abstract Override Methods
        
        protected override bool IsValidDomainModel(CommonModel::IDomainModel domainModel)
        {
            return domainModel is LWC2012DomainModel;
        }

        #endregion        

        #region Event Handler

        private void Settings_ValidationEventHandler(object sender, System.Xml.Schema.ValidationEventArgs e)
        {
            this.exceptions.Add(e.Exception);
        } 

        #endregion    
    }
}