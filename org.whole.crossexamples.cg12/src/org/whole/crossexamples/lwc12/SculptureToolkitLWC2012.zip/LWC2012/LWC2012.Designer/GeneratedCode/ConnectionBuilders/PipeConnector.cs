namespace LWC2012.Designer
{
    using System.Linq;
	using SDesign = Modelingsoft.Sculpture.SDesign.Common;
	using SModel = Modelingsoft.Sculpture.SModel.Common;
	
	public partial class PipeConnector : PipeConnectorBase
    {
    }
    
    public abstract class PipeConnectorBase : SDesign::ConnectionBuilder
    {
        #region Private Methods
        
        private global::System.Collections.Generic.IEnumerable<SDesign::ConnectionBuilder> myConnectors;
        
        #endregion

        #region Constructors

        public PipeConnectorBase()
        {
            this.myConnectors = this.GetConnectors(LWC2012Package.Instance.ComponentsProvider.GetConnectors());
        }

        #endregion

        #region Override Methods

        public override bool CanAcceptSource(SModel::IDomainObject source)
        {
            foreach (SDesign::ConnectionBuilder connectionBuilder in this.myConnectors)
            {
                if (true == connectionBuilder.CanAcceptSource(source))
                {
                    return true;
                }
            }

            return false;
        }

        public override bool CanAcceptSourceAndTarget(SModel::IDomainObject source, SModel::IDomainObject target)
        {
            foreach (SDesign::ConnectionBuilder connectionBuilder in this.myConnectors)
            {
                if (true == connectionBuilder.CanAcceptSourceAndTarget(source, target))
                {
                    return true;
                }
            }

            return false;
        }

        public override SModel::IDomainObject Connect(SModel::IDomainObject source, SModel::IDomainObject target)
        {
            foreach (SDesign::ConnectionBuilder connectionBuilder in this.myConnectors)
            {
                if (true == connectionBuilder.CanAcceptSourceAndTarget(source, target))
                {
                    return connectionBuilder.Connect(source, target);
                }
            }

            return null;
        }

        public override void Disconnect(SModel::IDomainObject source, SModel::IDomainObject target)
        {
			// Nothing to do here.
        }
        
		public override SDesign::RoutingStyle GetRoutingStyle()
        {
			return SDesign::RoutingStyle.Rectilinear;
        }
		
        #endregion

        #region Protected Methods

        protected virtual global::System.Collections.Generic.IEnumerable<SDesign::ConnectionBuilder> GetConnectors(global::System.Collections.Generic.Dictionary<string, SDesign::ConnectionBuilder> allConnectors)
        {
            return new global::System.Collections.Generic.List<SDesign::ConnectionBuilder>();
        }

        #endregion
    }
}