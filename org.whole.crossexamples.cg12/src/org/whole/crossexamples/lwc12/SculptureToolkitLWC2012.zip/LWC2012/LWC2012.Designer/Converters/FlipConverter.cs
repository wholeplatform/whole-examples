﻿namespace LWC2012.Designer
{
    using System;
    using System.Windows.Data;
    using LWC2012.Model;

    [ValueConversion(typeof(SystemEndDirection?), typeof(int))]
    public class FlipConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (null == ((SystemEndDirection?)value) || (SystemEndDirection.Exhaust == (SystemEndDirection)value))
            {
                return -1;
            }

            return 1;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
         return 1;
        }
    }
}
