namespace LWC2012.Model
{
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    public interface ISystemEnd : IConnectableElement
    {
        #region Properties

        SystemEndDirection Direction { get; set;  }

        #endregion        
    }    
}