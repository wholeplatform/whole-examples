namespace LWC2012.Model
{
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
        
    public partial class LWC2012Copier : LWC2012CopierBase
    {
        #region Constructors
        
        private LWC2012Copier()
        {
        }
        
        #endregion
        
        #region Public Static Methods
        
        public static CommonModel::IDomainCopier CreateNewInstance()
        {
            return new LWC2012Copier(); 
        }
        
        #endregion
    }
    
    public abstract class LWC2012CopierBase : CommonModel::DomainCopier
    {
        #region DomainCopier Members
        
        protected override void CheckOnModel(CommonModel::IDomainModel domainModel)
        {
            if (false == domainModel is LWC2012DomainModel)
            {
                throw new global::System.Exception("The domain model of the copied domain object is not valid."); 
            }
        }
        
        #endregion
    }
}