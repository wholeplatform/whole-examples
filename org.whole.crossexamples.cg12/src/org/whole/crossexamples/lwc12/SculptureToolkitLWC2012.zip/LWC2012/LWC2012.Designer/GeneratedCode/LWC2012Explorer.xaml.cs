namespace LWC2012.Designer
{
    public partial class LWC2012Explorer : global::System.Windows.Controls.UserControl
    {
        #region Constructors
        
        public LWC2012Explorer()
        {
            InitializeComponent();
            this.Loaded += new global::System.Windows.RoutedEventHandler(this.LWC2012Explorer_Loaded);
        }

        #endregion

        #region Private Methods

        private void LWC2012Explorer_Loaded(object sender, global::System.Windows.RoutedEventArgs e)
        {
            if (this.DataContext != LWC2012Package.Instance.Model.Root)
			{
				this.DataContext = LWC2012Package.Instance.Model.Root;
            	this.ExplorerTreeView.ModelRoot = LWC2012Package.Instance.Model.Root;
			}
        }

        #endregion
    }
}