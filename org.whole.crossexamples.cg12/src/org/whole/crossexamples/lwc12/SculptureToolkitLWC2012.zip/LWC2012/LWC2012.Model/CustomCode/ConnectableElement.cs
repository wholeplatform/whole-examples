namespace LWC2012.Model
{
    using System.Linq;
    using Modelingsoft.Sculpture.SModel.Common;

    internal partial class ConnectableElement
    {
        protected override ReadOnlyDomainCollection<IConnectableElement> OnGetConnectedElements()
        {
            DomainCollection<IConnectableElement> connectedElements = new DomainCollection<IConnectableElement>();
            
            var connectedPipes = this.DomainModel.Locate<IPipe>()
                                .Where(P => P.PipeIn == this || P.PipesOut.Contains(this));
            
            foreach (var pipe in connectedPipes)
            {
                this.AddElement(pipe.PipeIn, connectedElements);
                foreach (var element in pipe.PipesOut)
                {
                    this.AddElement(element, connectedElements);
                }
            }

            return new ReadOnlyDomainCollection<IConnectableElement>(connectedElements);
        }

        private void AddElement(IConnectableElement element, DomainCollection<IConnectableElement> connectedElements)
        {
            if (element != this && false == connectedElements.Contains(element))
            {
                connectedElements.Add(element);
            }
        }
    }
}