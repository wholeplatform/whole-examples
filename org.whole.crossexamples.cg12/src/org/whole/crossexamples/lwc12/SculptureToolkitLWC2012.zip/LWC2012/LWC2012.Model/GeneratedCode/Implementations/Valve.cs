namespace LWC2012.Model
{
    using System.Linq;
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    internal partial class Valve : ValveBase
    {
        #region Constructors
        
        protected internal Valve(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel)
            : base(domainObjectId, domainClass, domainModel)
        {
        }
        
        #endregion        
    }
    
    internal abstract class ValveBase : ConnectableElement, IValve
    {
        #region Events Args
        
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs EndsPropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("Ends");
        protected static readonly CommonModel::ModelChangedEventArgs EndsModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"Ends");     
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs TypePropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("Type");
        protected static readonly CommonModel::ModelChangedEventArgs TypeModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"Type");     
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs StatusPropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("Status");
        protected static readonly CommonModel::ModelChangedEventArgs StatusModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"Status");     
    
        #endregion

        #region Private Variables
        
        private ValveEnds ends;
        private ValveType type;
        private ValveStatus status;

        #endregion
        
        #region Constructors
        
        protected internal ValveBase(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel) 
            : base(domainObjectId, domainClass, domainModel)
        {
            this.status = ValveStatus.None;
            if (typeof(Valve) == this.GetType())
            {
                this.OnCreated();
            }
        }

        #endregion

        #region Features

        #region Properties
 
        public ValveEnds Ends
        {
             get
             {
                return this.ends;
             }
             
             set
             {
                 if (value != this.ends)
                {
                    this.OnEndsChanging(value);
                    EndsModelEventArgs.OldValue = this.ends;
                    this.ends = value;
                    EndsModelEventArgs.NewValue = this.ends;
                    this.OnModelChanged(EndsModelEventArgs, EndsPropertyEventArgs);
                    this.OnEndsChanged();
                 }
            }
        }
 
        public ValveType Type
        {
             get
             {
                return this.type;
             }
             
             set
             {
                 if (value != this.type)
                {
                    this.OnTypeChanging(value);
                    TypeModelEventArgs.OldValue = this.type;
                    this.type = value;
                    TypeModelEventArgs.NewValue = this.type;
                    this.OnModelChanged(TypeModelEventArgs, TypePropertyEventArgs);
                    this.OnTypeChanged();
                 }
            }
        }
 
        public ValveStatus Status
        {
             get
             {
                return this.status;
             }
             
             set
             {
                 if (value != this.status)
                {
                    this.OnStatusChanging(value);
                    StatusModelEventArgs.OldValue = this.status;
                    this.status = value;
                    StatusModelEventArgs.NewValue = this.status;
                    this.OnModelChanged(StatusModelEventArgs, StatusPropertyEventArgs);
                    this.OnStatusChanged();
                 }
            }
        }

        #endregion

        #endregion

        #region IDomainObject Members
        
        public override object Get(CommonModel::IDomainFeature feature)
        {
            switch (feature.Name)
            {
                case "Ends":
                    return this.Ends;
                case "Type":
                    return this.Type;
                case "Status":
                    return this.Status;
                default:
                    return base.Get(feature);
            }
        }
        
        public override void Set(CommonModel::IDomainFeature feature, object newValue)
        {
            switch (feature.Name)
            {
                case "Ends":
                    this.Ends = (ValveEnds)newValue;
                    break;
                case "Type":
                    this.Type = (ValveType)newValue;
                    break;
                case "Status":
                    this.Status = (ValveStatus)newValue;
                    break;
                default:
                    base.Set(feature, newValue);
                    break;
            }
        }
        
        #endregion

        #region Extensibility Methods
        
        protected virtual void OnEndsChanging(ValveEnds ends) 
        { 
        }
    
        protected virtual void OnEndsChanged() 
        { 
        }
        
        protected virtual void OnTypeChanging(ValveType type) 
        { 
        }
    
        protected virtual void OnTypeChanged() 
        { 
        }
        
        protected virtual void OnStatusChanging(ValveStatus status) 
        { 
        }
    
        protected virtual void OnStatusChanged() 
        { 
        }

        #endregion
    }
}