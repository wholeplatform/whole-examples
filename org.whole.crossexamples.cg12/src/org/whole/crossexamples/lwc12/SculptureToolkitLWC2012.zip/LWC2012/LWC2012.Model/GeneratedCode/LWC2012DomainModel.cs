namespace LWC2012.Model
{
    using System.Linq;
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;  
    
    [global::System.ComponentModel.Composition.Export(typeof(CommonModel::IDomainModel))]
    [global::System.ComponentModel.Composition.ExportMetadata("ModelName", "LWC2012")]
    [global::System.ComponentModel.Composition.PartCreationPolicyAttribute(global::System.ComponentModel.Composition.CreationPolicy.NonShared)]
    public partial class LWC2012DomainModel : LWC2012DomainModelBase
    {    
        #region Constructors
        
        public LWC2012DomainModel()
             : base(true)
          {
          }
        
        public LWC2012DomainModel(bool loadMetaData = true)
             : base(loadMetaData)
          {
          }
        
        #endregion
        
        #region Public Static Methods
        
        public static CommonModel::IDomainModel CreateNewInstance()
        {
            return new LWC2012DomainModel(); 
        }
        
        #endregion
    }
    
    public abstract class LWC2012DomainModelBase : CommonModel::DomainModel
    {    
        #region Constructors

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors", Justification = "Generated Code")]
        public LWC2012DomainModelBase(bool loadMetaData = true) 
        {
            this.DomainFactory = new LWC2012Factory(this);

            CommonModel::IDomainClass rootDomainClass = null;

            if (true == loadMetaData)
            {
                this.MetaData = this.GetMetaData();
                rootDomainClass = this.GetMetadataDomainClass<IPIDiagram>();
            }
            
            this.Root = new PIDiagram(global::System.Guid.NewGuid(), rootDomainClass, this);            
            this.InitializeDomainObject(this, new CommonModel::IntializeDomainObjectEventArgs(this.Root));
            this.OnCreated();
        }
        
        #endregion
        
        #region Properties
        
        public override string Name
        {
            get
            {
                return "LWC2012";
            }
        }
        
        #endregion
        
        #region MetaData
        
        private CommonModel::IDomainModel GetMetaData()
        {
             CommonModel::IDomainModel domainModel = new CommonModel::SModelDomainModel(false);
            
            ////Root Decleration
            ((CommonModel::ISModelRoot)domainModel.Root).Name = "LWC2012";
            ((CommonModel::ISModelRoot)domainModel.Root).ProjectName = "LWC2012.Model";
            ((CommonModel::ISModelRoot)domainModel.Root).ProjectNamespace = "LWC2012.Model";
            ((CommonModel::ISModelRoot)domainModel.Root).GenerationPath = @"GeneratedCode";
            
    
            ////Enumerations
            
            ////SensorType
            
            CommonModel::IDomainEnumeration sensorTypeEnum = domainModel.DomainFactory.Create<CommonModel::IDomainEnumeration>();
            sensorTypeEnum.Name = "SensorType";
            sensorTypeEnum.InstanceTypeFullName = typeof(SensorType).FullName;
            sensorTypeEnum.InstanceType = typeof(SensorType);
            
            ////Literals
 
            ////Pressure
            CommonModel::IDomainEnumerationLiteral sensorType_PressureEnumLiteral = domainModel.DomainFactory.Create<CommonModel::IDomainEnumerationLiteral>(); 
            sensorType_PressureEnumLiteral.Name = "Pressure";
            sensorType_PressureEnumLiteral.Value = 0;
            sensorTypeEnum.Literals.Add(sensorType_PressureEnumLiteral);
 
            ////Flow
            CommonModel::IDomainEnumerationLiteral sensorType_FlowEnumLiteral = domainModel.DomainFactory.Create<CommonModel::IDomainEnumerationLiteral>(); 
            sensorType_FlowEnumLiteral.Name = "Flow";
            sensorType_FlowEnumLiteral.Value = 2;
            sensorTypeEnum.Literals.Add(sensorType_FlowEnumLiteral);
 
            ////Temperature
            CommonModel::IDomainEnumerationLiteral sensorType_TemperatureEnumLiteral = domainModel.DomainFactory.Create<CommonModel::IDomainEnumerationLiteral>(); 
            sensorType_TemperatureEnumLiteral.Name = "Temperature";
            sensorType_TemperatureEnumLiteral.Value = 3;
            sensorTypeEnum.Literals.Add(sensorType_TemperatureEnumLiteral);
            
            ////SystemEndDirection
            
            CommonModel::IDomainEnumeration systemEndDirectionEnum = domainModel.DomainFactory.Create<CommonModel::IDomainEnumeration>();
            systemEndDirectionEnum.Name = "SystemEndDirection";
            systemEndDirectionEnum.InstanceTypeFullName = typeof(SystemEndDirection).FullName;
            systemEndDirectionEnum.InstanceType = typeof(SystemEndDirection);
            
            ////Literals
 
            ////Source
            CommonModel::IDomainEnumerationLiteral systemEndDirection_SourceEnumLiteral = domainModel.DomainFactory.Create<CommonModel::IDomainEnumerationLiteral>(); 
            systemEndDirection_SourceEnumLiteral.Name = "Source";
            systemEndDirection_SourceEnumLiteral.Value = 0;
            systemEndDirectionEnum.Literals.Add(systemEndDirection_SourceEnumLiteral);
 
            ////Exhaust
            CommonModel::IDomainEnumerationLiteral systemEndDirection_ExhaustEnumLiteral = domainModel.DomainFactory.Create<CommonModel::IDomainEnumerationLiteral>(); 
            systemEndDirection_ExhaustEnumLiteral.Name = "Exhaust";
            systemEndDirection_ExhaustEnumLiteral.Value = 1;
            systemEndDirectionEnum.Literals.Add(systemEndDirection_ExhaustEnumLiteral);
            
            ////ValveType
            
            CommonModel::IDomainEnumeration valveTypeEnum = domainModel.DomainFactory.Create<CommonModel::IDomainEnumeration>();
            valveTypeEnum.Name = "ValveType";
            valveTypeEnum.InstanceTypeFullName = typeof(ValveType).FullName;
            valveTypeEnum.InstanceType = typeof(ValveType);
            
            ////Literals
 
            ////Manual
            CommonModel::IDomainEnumerationLiteral valveType_ManualEnumLiteral = domainModel.DomainFactory.Create<CommonModel::IDomainEnumerationLiteral>(); 
            valveType_ManualEnumLiteral.Name = "Manual";
            valveType_ManualEnumLiteral.Value = 0;
            valveTypeEnum.Literals.Add(valveType_ManualEnumLiteral);
 
            ////Control
            CommonModel::IDomainEnumerationLiteral valveType_ControlEnumLiteral = domainModel.DomainFactory.Create<CommonModel::IDomainEnumerationLiteral>(); 
            valveType_ControlEnumLiteral.Name = "Control";
            valveType_ControlEnumLiteral.Value = 1;
            valveTypeEnum.Literals.Add(valveType_ControlEnumLiteral);
            
            ////ValveStatus
            
            CommonModel::IDomainEnumeration valveStatusEnum = domainModel.DomainFactory.Create<CommonModel::IDomainEnumeration>();
            valveStatusEnum.Name = "ValveStatus";
            valveStatusEnum.InstanceTypeFullName = typeof(ValveStatus).FullName;
            valveStatusEnum.InstanceType = typeof(ValveStatus);
            
            ////Literals
 
            ////Left
            CommonModel::IDomainEnumerationLiteral valveStatus_LeftEnumLiteral = domainModel.DomainFactory.Create<CommonModel::IDomainEnumerationLiteral>(); 
            valveStatus_LeftEnumLiteral.Name = "Left";
            valveStatus_LeftEnumLiteral.Value = 0;
            valveStatusEnum.Literals.Add(valveStatus_LeftEnumLiteral);
 
            ////Right
            CommonModel::IDomainEnumerationLiteral valveStatus_RightEnumLiteral = domainModel.DomainFactory.Create<CommonModel::IDomainEnumerationLiteral>(); 
            valveStatus_RightEnumLiteral.Name = "Right";
            valveStatus_RightEnumLiteral.Value = 1;
            valveStatusEnum.Literals.Add(valveStatus_RightEnumLiteral);
 
            ////Both
            CommonModel::IDomainEnumerationLiteral valveStatus_BothEnumLiteral = domainModel.DomainFactory.Create<CommonModel::IDomainEnumerationLiteral>(); 
            valveStatus_BothEnumLiteral.Name = "Both";
            valveStatus_BothEnumLiteral.Value = 2;
            valveStatusEnum.Literals.Add(valveStatus_BothEnumLiteral);
 
            ////None
            CommonModel::IDomainEnumerationLiteral valveStatus_NoneEnumLiteral = domainModel.DomainFactory.Create<CommonModel::IDomainEnumerationLiteral>(); 
            valveStatus_NoneEnumLiteral.Name = "None";
            valveStatus_NoneEnumLiteral.Value = 3;
            valveStatusEnum.Literals.Add(valveStatus_NoneEnumLiteral);
            
            ////ValveEnds
            
            CommonModel::IDomainEnumeration valveEndsEnum = domainModel.DomainFactory.Create<CommonModel::IDomainEnumeration>();
            valveEndsEnum.Name = "ValveEnds";
            valveEndsEnum.InstanceTypeFullName = typeof(ValveEnds).FullName;
            valveEndsEnum.InstanceType = typeof(ValveEnds);
            
            ////Literals
 
            ////Two
            CommonModel::IDomainEnumerationLiteral valveEnds_TwoEnumLiteral = domainModel.DomainFactory.Create<CommonModel::IDomainEnumerationLiteral>(); 
            valveEnds_TwoEnumLiteral.Name = "Two";
            valveEnds_TwoEnumLiteral.Value = 0;
            valveEndsEnum.Literals.Add(valveEnds_TwoEnumLiteral);
 
            ////Three
            CommonModel::IDomainEnumerationLiteral valveEnds_ThreeEnumLiteral = domainModel.DomainFactory.Create<CommonModel::IDomainEnumerationLiteral>(); 
            valveEnds_ThreeEnumLiteral.Name = "Three";
            valveEnds_ThreeEnumLiteral.Value = 1;
            valveEndsEnum.Literals.Add(valveEnds_ThreeEnumLiteral);
            
            ////Domain Classes
            
            ////NamedElement
            
            CommonModel::IDomainClass namedElementDomainClass = domainModel.DomainFactory.Create<CommonModel::IDomainClass>();
            namedElementDomainClass.IsRoot = false; 
            namedElementDomainClass.Name = "NamedElement";
            namedElementDomainClass.IsAbstract = false;
            namedElementDomainClass.InstanceTypeFullName = typeof(INamedElement).FullName;
            namedElementDomainClass.InstanceType = typeof(INamedElement);
            
            ////Properties
            
            ////Name
            CommonModel::IDomainProperty namedElement_NameDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            namedElement_NameDomainProperty.Name = "Name";            
            namedElement_NameDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "String");
            namedElement_NameDomainProperty.UpperBound = 1;
            namedElement_NameDomainProperty.LowerBound = 1;
            namedElement_NameDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            namedElement_NameDomainProperty.IsId = true; 
            namedElement_NameDomainProperty.DefaultValue = null;
            namedElement_NameDomainProperty.Description = null;
            namedElement_NameDomainProperty.IsUnique = true;            
            namedElementDomainClass.Properties.Add(namedElement_NameDomainProperty);            
            
            ////Description
            CommonModel::IDomainProperty namedElement_DescriptionDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            namedElement_DescriptionDomainProperty.Name = "Description";            
            namedElement_DescriptionDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "String");
            namedElement_DescriptionDomainProperty.UpperBound = 1;
            namedElement_DescriptionDomainProperty.LowerBound = 0;
            namedElement_DescriptionDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            namedElement_DescriptionDomainProperty.IsId = false; 
            namedElement_DescriptionDomainProperty.DefaultValue = null;
            namedElement_DescriptionDomainProperty.Description = null;
            namedElement_DescriptionDomainProperty.IsUnique = false;            
            namedElementDomainClass.Properties.Add(namedElement_DescriptionDomainProperty);            
            
            ////PIDiagram
            
            CommonModel::IDomainClass pIDiagramDomainClass = domainModel.DomainFactory.Create<CommonModel::IDomainClass>();
            pIDiagramDomainClass.IsRoot = true; 
            pIDiagramDomainClass.Name = "PIDiagram";
            pIDiagramDomainClass.IsAbstract = false;
            pIDiagramDomainClass.InstanceTypeFullName = typeof(IPIDiagram).FullName;
            pIDiagramDomainClass.InstanceType = typeof(IPIDiagram);
            
            ////Properties
            
            ////RequestedTemperature
            CommonModel::IDomainProperty pIDiagram_RequestedTemperatureDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            pIDiagram_RequestedTemperatureDomainProperty.Name = "RequestedTemperature";            
            pIDiagram_RequestedTemperatureDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "Int32");
            pIDiagram_RequestedTemperatureDomainProperty.UpperBound = 1;
            pIDiagram_RequestedTemperatureDomainProperty.LowerBound = 1;
            pIDiagram_RequestedTemperatureDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            pIDiagram_RequestedTemperatureDomainProperty.IsId = false; 
            pIDiagram_RequestedTemperatureDomainProperty.DefaultValue = null;
            pIDiagram_RequestedTemperatureDomainProperty.Description = null;
            pIDiagram_RequestedTemperatureDomainProperty.IsUnique = false;            
            pIDiagramDomainClass.Properties.Add(pIDiagram_RequestedTemperatureDomainProperty);            
            
            ////RoomTemperature
            CommonModel::IDomainProperty pIDiagram_RoomTemperatureDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            pIDiagram_RoomTemperatureDomainProperty.Name = "RoomTemperature";            
            pIDiagram_RoomTemperatureDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "Int32");
            pIDiagram_RoomTemperatureDomainProperty.UpperBound = 1;
            pIDiagram_RoomTemperatureDomainProperty.LowerBound = 1;
            pIDiagram_RoomTemperatureDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            pIDiagram_RoomTemperatureDomainProperty.IsId = false; 
            pIDiagram_RoomTemperatureDomainProperty.DefaultValue = null;
            pIDiagram_RoomTemperatureDomainProperty.Description = null;
            pIDiagram_RoomTemperatureDomainProperty.IsUnique = false;            
            pIDiagramDomainClass.Properties.Add(pIDiagram_RoomTemperatureDomainProperty);            
            
            ////ConnectableElement
            
            CommonModel::IDomainClass connectableElementDomainClass = domainModel.DomainFactory.Create<CommonModel::IDomainClass>();
            connectableElementDomainClass.IsRoot = false; 
            connectableElementDomainClass.Name = "ConnectableElement";
            connectableElementDomainClass.IsAbstract = false;
            connectableElementDomainClass.InstanceTypeFullName = typeof(IConnectableElement).FullName;
            connectableElementDomainClass.InstanceType = typeof(IConnectableElement);
            
            ////Pipe
            
            CommonModel::IDomainClass pipeDomainClass = domainModel.DomainFactory.Create<CommonModel::IDomainClass>();
            pipeDomainClass.IsRoot = false; 
            pipeDomainClass.Name = "Pipe";
            pipeDomainClass.IsAbstract = false;
            pipeDomainClass.InstanceTypeFullName = typeof(IPipe).FullName;
            pipeDomainClass.InstanceType = typeof(IPipe);
            
            ////Properties
            
            ////Diameter
            CommonModel::IDomainProperty pipe_DiameterDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            pipe_DiameterDomainProperty.Name = "Diameter";            
            pipe_DiameterDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "Int32");
            pipe_DiameterDomainProperty.UpperBound = 1;
            pipe_DiameterDomainProperty.LowerBound = 1;
            pipe_DiameterDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            pipe_DiameterDomainProperty.IsId = false; 
            pipe_DiameterDomainProperty.DefaultValue = null;
            pipe_DiameterDomainProperty.Description = null;
            pipe_DiameterDomainProperty.IsUnique = false;            
            pipeDomainClass.Properties.Add(pipe_DiameterDomainProperty);            
            
            ////Length
            CommonModel::IDomainProperty pipe_LengthDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            pipe_LengthDomainProperty.Name = "Length";            
            pipe_LengthDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "Int32");
            pipe_LengthDomainProperty.UpperBound = 1;
            pipe_LengthDomainProperty.LowerBound = 1;
            pipe_LengthDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            pipe_LengthDomainProperty.IsId = false; 
            pipe_LengthDomainProperty.DefaultValue = null;
            pipe_LengthDomainProperty.Description = null;
            pipe_LengthDomainProperty.IsUnique = false;            
            pipeDomainClass.Properties.Add(pipe_LengthDomainProperty);            
            
            ////Boiler
            
            CommonModel::IDomainClass boilerDomainClass = domainModel.DomainFactory.Create<CommonModel::IDomainClass>();
            boilerDomainClass.IsRoot = false; 
            boilerDomainClass.Name = "Boiler";
            boilerDomainClass.IsAbstract = false;
            boilerDomainClass.InstanceTypeFullName = typeof(IBoiler).FullName;
            boilerDomainClass.InstanceType = typeof(IBoiler);
            
            ////Properties
            
            ////Temperature
            CommonModel::IDomainProperty boiler_TemperatureDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            boiler_TemperatureDomainProperty.Name = "Temperature";            
            boiler_TemperatureDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "Int32");
            boiler_TemperatureDomainProperty.UpperBound = 1;
            boiler_TemperatureDomainProperty.LowerBound = 1;
            boiler_TemperatureDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            boiler_TemperatureDomainProperty.IsId = false; 
            boiler_TemperatureDomainProperty.DefaultValue = null;
            boiler_TemperatureDomainProperty.Description = null;
            boiler_TemperatureDomainProperty.IsUnique = false;            
            boilerDomainClass.Properties.Add(boiler_TemperatureDomainProperty);            
            
            ////Burner
            
            CommonModel::IDomainClass burnerDomainClass = domainModel.DomainFactory.Create<CommonModel::IDomainClass>();
            burnerDomainClass.IsRoot = false; 
            burnerDomainClass.Name = "Burner";
            burnerDomainClass.IsAbstract = false;
            burnerDomainClass.InstanceTypeFullName = typeof(IBurner).FullName;
            burnerDomainClass.InstanceType = typeof(IBurner);
            
            ////Properties
            
            ////IsOn
            CommonModel::IDomainProperty burner_IsOnDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            burner_IsOnDomainProperty.Name = "IsOn";            
            burner_IsOnDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "Boolean");
            burner_IsOnDomainProperty.UpperBound = 1;
            burner_IsOnDomainProperty.LowerBound = 1;
            burner_IsOnDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            burner_IsOnDomainProperty.IsId = false; 
            burner_IsOnDomainProperty.DefaultValue = "False";
            burner_IsOnDomainProperty.Description = null;
            burner_IsOnDomainProperty.IsUnique = false;            
            burnerDomainClass.Properties.Add(burner_IsOnDomainProperty);            
            
            ////Pump
            
            CommonModel::IDomainClass pumpDomainClass = domainModel.DomainFactory.Create<CommonModel::IDomainClass>();
            pumpDomainClass.IsRoot = false; 
            pumpDomainClass.Name = "Pump";
            pumpDomainClass.IsAbstract = false;
            pumpDomainClass.InstanceTypeFullName = typeof(IPump).FullName;
            pumpDomainClass.InstanceType = typeof(IPump);
            
            ////Properties
            
            ////IsOn
            CommonModel::IDomainProperty pump_IsOnDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            pump_IsOnDomainProperty.Name = "IsOn";            
            pump_IsOnDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "Boolean");
            pump_IsOnDomainProperty.UpperBound = 1;
            pump_IsOnDomainProperty.LowerBound = 1;
            pump_IsOnDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            pump_IsOnDomainProperty.IsId = false; 
            pump_IsOnDomainProperty.DefaultValue = "False";
            pump_IsOnDomainProperty.Description = null;
            pump_IsOnDomainProperty.IsUnique = false;            
            pumpDomainClass.Properties.Add(pump_IsOnDomainProperty);            
            
            ////Radiator
            
            CommonModel::IDomainClass radiatorDomainClass = domainModel.DomainFactory.Create<CommonModel::IDomainClass>();
            radiatorDomainClass.IsRoot = false; 
            radiatorDomainClass.Name = "Radiator";
            radiatorDomainClass.IsAbstract = false;
            radiatorDomainClass.InstanceTypeFullName = typeof(IRadiator).FullName;
            radiatorDomainClass.InstanceType = typeof(IRadiator);
            
            ////Properties
            
            ////RequestHeat
            CommonModel::IDomainProperty radiator_RequestHeatDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            radiator_RequestHeatDomainProperty.Name = "RequestHeat";            
            radiator_RequestHeatDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "Boolean");
            radiator_RequestHeatDomainProperty.UpperBound = 1;
            radiator_RequestHeatDomainProperty.LowerBound = 1;
            radiator_RequestHeatDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            radiator_RequestHeatDomainProperty.IsId = false; 
            radiator_RequestHeatDomainProperty.DefaultValue = null;
            radiator_RequestHeatDomainProperty.Description = null;
            radiator_RequestHeatDomainProperty.IsUnique = false;            
            radiatorDomainClass.Properties.Add(radiator_RequestHeatDomainProperty);            
            
            ////Sensor
            
            CommonModel::IDomainClass sensorDomainClass = domainModel.DomainFactory.Create<CommonModel::IDomainClass>();
            sensorDomainClass.IsRoot = false; 
            sensorDomainClass.Name = "Sensor";
            sensorDomainClass.IsAbstract = false;
            sensorDomainClass.InstanceTypeFullName = typeof(ISensor).FullName;
            sensorDomainClass.InstanceType = typeof(ISensor);
            
            ////Properties
            
            ////Type
            CommonModel::IDomainProperty sensor_TypeDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            sensor_TypeDomainProperty.Name = "Type";            
            sensor_TypeDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "SensorType");
            sensor_TypeDomainProperty.UpperBound = 1;
            sensor_TypeDomainProperty.LowerBound = 1;
            sensor_TypeDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            sensor_TypeDomainProperty.IsId = false; 
            sensor_TypeDomainProperty.DefaultValue = null;
            sensor_TypeDomainProperty.Description = null;
            sensor_TypeDomainProperty.IsUnique = false;            
            sensorDomainClass.Properties.Add(sensor_TypeDomainProperty);            
            
            ////Degree
            CommonModel::IDomainProperty sensor_DegreeDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            sensor_DegreeDomainProperty.Name = "Degree";            
            sensor_DegreeDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "Int32");
            sensor_DegreeDomainProperty.UpperBound = 1;
            sensor_DegreeDomainProperty.LowerBound = 1;
            sensor_DegreeDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            sensor_DegreeDomainProperty.IsId = false; 
            sensor_DegreeDomainProperty.DefaultValue = null;
            sensor_DegreeDomainProperty.Description = null;
            sensor_DegreeDomainProperty.IsUnique = false;            
            sensorDomainClass.Properties.Add(sensor_DegreeDomainProperty);            
            
            ////SystemEnd
            
            CommonModel::IDomainClass systemEndDomainClass = domainModel.DomainFactory.Create<CommonModel::IDomainClass>();
            systemEndDomainClass.IsRoot = false; 
            systemEndDomainClass.Name = "SystemEnd";
            systemEndDomainClass.IsAbstract = false;
            systemEndDomainClass.InstanceTypeFullName = typeof(ISystemEnd).FullName;
            systemEndDomainClass.InstanceType = typeof(ISystemEnd);
            
            ////Properties
            
            ////Direction
            CommonModel::IDomainProperty systemEnd_DirectionDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            systemEnd_DirectionDomainProperty.Name = "Direction";            
            systemEnd_DirectionDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "SystemEndDirection");
            systemEnd_DirectionDomainProperty.UpperBound = 1;
            systemEnd_DirectionDomainProperty.LowerBound = 1;
            systemEnd_DirectionDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            systemEnd_DirectionDomainProperty.IsId = false; 
            systemEnd_DirectionDomainProperty.DefaultValue = null;
            systemEnd_DirectionDomainProperty.Description = null;
            systemEnd_DirectionDomainProperty.IsUnique = false;            
            systemEndDomainClass.Properties.Add(systemEnd_DirectionDomainProperty);            
            
            ////Valve
            
            CommonModel::IDomainClass valveDomainClass = domainModel.DomainFactory.Create<CommonModel::IDomainClass>();
            valveDomainClass.IsRoot = false; 
            valveDomainClass.Name = "Valve";
            valveDomainClass.IsAbstract = false;
            valveDomainClass.InstanceTypeFullName = typeof(IValve).FullName;
            valveDomainClass.InstanceType = typeof(IValve);
            
            ////Properties
            
            ////Ends
            CommonModel::IDomainProperty valve_EndsDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            valve_EndsDomainProperty.Name = "Ends";            
            valve_EndsDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "ValveEnds");
            valve_EndsDomainProperty.UpperBound = 1;
            valve_EndsDomainProperty.LowerBound = 1;
            valve_EndsDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            valve_EndsDomainProperty.IsId = false; 
            valve_EndsDomainProperty.DefaultValue = null;
            valve_EndsDomainProperty.Description = null;
            valve_EndsDomainProperty.IsUnique = false;            
            valveDomainClass.Properties.Add(valve_EndsDomainProperty);            
            
            ////Type
            CommonModel::IDomainProperty valve_TypeDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            valve_TypeDomainProperty.Name = "Type";            
            valve_TypeDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "ValveType");
            valve_TypeDomainProperty.UpperBound = 1;
            valve_TypeDomainProperty.LowerBound = 1;
            valve_TypeDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            valve_TypeDomainProperty.IsId = false; 
            valve_TypeDomainProperty.DefaultValue = null;
            valve_TypeDomainProperty.Description = null;
            valve_TypeDomainProperty.IsUnique = false;            
            valveDomainClass.Properties.Add(valve_TypeDomainProperty);            
            
            ////Status
            CommonModel::IDomainProperty valve_StatusDomainProperty = domainModel.DomainFactory.Create<CommonModel::IDomainProperty>();
            valve_StatusDomainProperty.Name = "Status";            
            valve_StatusDomainProperty.Type = domainModel.Locate<CommonModel::IDomainType>().First(C => C.Name == "ValveStatus");
            valve_StatusDomainProperty.UpperBound = 1;
            valve_StatusDomainProperty.LowerBound = 1;
            valve_StatusDomainProperty.PropertyKind = CommonModel::PropertyKind.Normal;
            valve_StatusDomainProperty.IsId = false; 
            valve_StatusDomainProperty.DefaultValue = "None";
            valve_StatusDomainProperty.Description = null;
            valve_StatusDomainProperty.IsUnique = false;            
            valveDomainClass.Properties.Add(valve_StatusDomainProperty);            
          
            ////Domain Classes References

            ////PIDiagram References
                   
            ////Elements
            CommonModel::IDomainReference pIDiagram_ElementsDomainReference = domainModel.DomainFactory.Create<CommonModel::IDomainReference>();
            pIDiagram_ElementsDomainReference.Name = "Elements";
            pIDiagram_ElementsDomainReference.Type = connectableElementDomainClass;            
            pIDiagram_ElementsDomainReference.UpperBound = -1;
            pIDiagram_ElementsDomainReference.LowerBound = 1;
            pIDiagram_ElementsDomainReference.DefaultValue = string.Empty;
            pIDiagram_ElementsDomainReference.Description = string.Empty;
            pIDiagram_ElementsDomainReference.IsUnique = false;            
            pIDiagram_ElementsDomainReference.PropertyKind = CommonModel::PropertyKind.Normal;
            pIDiagram_ElementsDomainReference.IsContainment = true;
            pIDiagramDomainClass.References.Add(pIDiagram_ElementsDomainReference);            
                   
            ////Pipes
            CommonModel::IDomainReference pIDiagram_PipesDomainReference = domainModel.DomainFactory.Create<CommonModel::IDomainReference>();
            pIDiagram_PipesDomainReference.Name = "Pipes";
            pIDiagram_PipesDomainReference.Type = pipeDomainClass;            
            pIDiagram_PipesDomainReference.UpperBound = -1;
            pIDiagram_PipesDomainReference.LowerBound = 0;
            pIDiagram_PipesDomainReference.DefaultValue = string.Empty;
            pIDiagram_PipesDomainReference.Description = string.Empty;
            pIDiagram_PipesDomainReference.IsUnique = false;            
            pIDiagram_PipesDomainReference.PropertyKind = CommonModel::PropertyKind.Normal;
            pIDiagram_PipesDomainReference.IsContainment = true;
            pIDiagramDomainClass.References.Add(pIDiagram_PipesDomainReference);            

            ////ConnectableElement References
                   
            ////ConnectedElements
            CommonModel::IDomainReference connectableElement_ConnectedElementsDomainReference = domainModel.DomainFactory.Create<CommonModel::IDomainReference>();
            connectableElement_ConnectedElementsDomainReference.Name = "ConnectedElements";
            connectableElement_ConnectedElementsDomainReference.Type = connectableElementDomainClass;            
            connectableElement_ConnectedElementsDomainReference.UpperBound = -1;
            connectableElement_ConnectedElementsDomainReference.LowerBound = 0;
            connectableElement_ConnectedElementsDomainReference.DefaultValue = string.Empty;
            connectableElement_ConnectedElementsDomainReference.Description = string.Empty;
            connectableElement_ConnectedElementsDomainReference.IsUnique = false;            
            connectableElement_ConnectedElementsDomainReference.PropertyKind = CommonModel::PropertyKind.CalculatedValue;
            connectableElement_ConnectedElementsDomainReference.IsContainment = false;
            connectableElementDomainClass.References.Add(connectableElement_ConnectedElementsDomainReference);            

            ////Pipe References
                   
            ////PipeIn
            CommonModel::IDomainReference pipe_PipeInDomainReference = domainModel.DomainFactory.Create<CommonModel::IDomainReference>();
            pipe_PipeInDomainReference.Name = "PipeIn";
            pipe_PipeInDomainReference.Type = connectableElementDomainClass;            
            pipe_PipeInDomainReference.UpperBound = 1;
            pipe_PipeInDomainReference.LowerBound = 1;
            pipe_PipeInDomainReference.DefaultValue = string.Empty;
            pipe_PipeInDomainReference.Description = string.Empty;
            pipe_PipeInDomainReference.IsUnique = false;            
            pipe_PipeInDomainReference.PropertyKind = CommonModel::PropertyKind.Normal;
            pipe_PipeInDomainReference.IsContainment = false;
            pipeDomainClass.References.Add(pipe_PipeInDomainReference);            
                   
            ////PipesOut
            CommonModel::IDomainReference pipe_PipesOutDomainReference = domainModel.DomainFactory.Create<CommonModel::IDomainReference>();
            pipe_PipesOutDomainReference.Name = "PipesOut";
            pipe_PipesOutDomainReference.Type = connectableElementDomainClass;            
            pipe_PipesOutDomainReference.UpperBound = -1;
            pipe_PipesOutDomainReference.LowerBound = 0;
            pipe_PipesOutDomainReference.DefaultValue = string.Empty;
            pipe_PipesOutDomainReference.Description = string.Empty;
            pipe_PipesOutDomainReference.IsUnique = false;            
            pipe_PipesOutDomainReference.PropertyKind = CommonModel::PropertyKind.Normal;
            pipe_PipesOutDomainReference.IsContainment = false;
            pipeDomainClass.References.Add(pipe_PipesOutDomainReference);            
          
            ////Super Types            
            pIDiagramDomainClass.SuperType = namedElementDomainClass;
            connectableElementDomainClass.SuperType = namedElementDomainClass;
            pipeDomainClass.SuperType = namedElementDomainClass;
            boilerDomainClass.SuperType = connectableElementDomainClass;
            burnerDomainClass.SuperType = connectableElementDomainClass;
            pumpDomainClass.SuperType = connectableElementDomainClass;
            radiatorDomainClass.SuperType = connectableElementDomainClass;
            sensorDomainClass.SuperType = connectableElementDomainClass;
            systemEndDomainClass.SuperType = connectableElementDomainClass;
            valveDomainClass.SuperType = connectableElementDomainClass;
            
            ((CommonModel::ISModelRoot)domainModel.Root).Classifiers.AddRange(domainModel.Locate<CommonModel::IDomainClassifier>().Where(classifier => false == CommonModel::DataTypeHelper.GetDefaultDataTypes().Contains(classifier.InstanceType))); 
            
            return domainModel;
        }
        
        #endregion        
    }
}