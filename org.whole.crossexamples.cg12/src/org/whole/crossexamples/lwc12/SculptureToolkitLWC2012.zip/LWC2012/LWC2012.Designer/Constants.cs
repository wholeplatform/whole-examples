﻿namespace LWC2012.Designer
{
    public static partial class Constants
    {
        public const string ProductName = @"LWC2012.Designer";
        public const string Author = @"";
        public const string Version = "1.0";
        public const string PackageId = "96c83030-f2fe-4a4b-8e50-7bdb6ecba379";
        public const string EditorFactoryId = "4517f49f-ecc9-49ef-b3b6-ef592dea29f4";
        public const string ExplorerWindowId = "76e4dabc-9149-4f26-9776-7c58836b1f56";
        public const string DetailsWindowId = "6f61bacb-b939-49ec-b970-1b50656b027d";
    }
}