namespace LWC2012.Model
{
    public enum ValveType
    {
        Manual = 0,
        Control = 1,
    }
}