namespace LWC2012.Model
{
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    public interface INamedElement : CommonModel::IDomainObject
    {
        #region Properties

        global::System.String Name { get; set;  }

        global::System.String Description { get; set;  }

        #endregion        
    }    
}