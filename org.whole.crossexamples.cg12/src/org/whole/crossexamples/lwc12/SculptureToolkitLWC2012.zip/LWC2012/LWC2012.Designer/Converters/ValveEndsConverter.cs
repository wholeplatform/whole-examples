﻿namespace LWC2012.Designer
{
    using System;
    using System.Windows;
    using System.Windows.Data;
    using LWC2012.Model;

    [ValueConversion(typeof(ValveEnds?), typeof(Visibility))]
    public class ValveEndsConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (null == ((ValveEnds?)value) || ValveEnds.Two == ((ValveEnds?)value))
            {
                return Visibility.Collapsed;                
            }

            return Visibility.Visible;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (Visibility.Visible == ((Visibility)value))
            {
                return ValveEnds.Three;
            }
            else
            {
                return ValveEnds.Two;
            }
        }
    }
}