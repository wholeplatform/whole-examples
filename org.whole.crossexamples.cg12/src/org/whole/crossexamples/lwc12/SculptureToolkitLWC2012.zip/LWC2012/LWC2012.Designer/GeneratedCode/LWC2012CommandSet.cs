namespace LWC2012.Designer
{
    using SDesign = Modelingsoft.Sculpture.SDesign.Common;
    
    public sealed partial class LWC2012CommandSet : LWC2012CommandSetBase
    {
    }
    
    public abstract class LWC2012CommandSetBase : SDesign::SDesignCommandSet
    {
    }
}