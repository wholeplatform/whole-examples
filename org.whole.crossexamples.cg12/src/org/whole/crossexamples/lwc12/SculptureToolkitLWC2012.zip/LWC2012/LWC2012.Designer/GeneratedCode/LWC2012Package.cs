namespace LWC2012.Designer
{
    using System.Linq;
    using ComponentModelHost = Microsoft.VisualStudio.ComponentModelHost;
    using Shell = Microsoft.VisualStudio.Shell;
    using Interop = Microsoft.VisualStudio.Shell.Interop;
    using SDesign = Modelingsoft.Sculpture.SDesign.Common;
    using SDiagram = Modelingsoft.Sculpture.SDiagram.Model;
    using LWC2012Model = LWC2012.Model;
    using VSHost = Microsoft.VisualStudio.TextTemplating.VSHost;
    
    [global::System.Runtime.InteropServices.Guid(Constants.PackageId)]
    public sealed partial class LWC2012Package : LWC2012PackageBase
    {
    }
    
    [Shell::DefaultRegistryRoot("Software\\Microsoft\\VisualStudio\\10.0")]
    [Shell::PackageRegistration(RegisterUsing = Shell::RegistrationMethod.Assembly, UseManagedResourcesOnly = true)]
    [Shell::InstalledProductRegistration("#110", "#112", "1.0", IconResourceID = 400)]
    [Shell::ProvideToolWindow(typeof(LWC2012ExplorerToolWindow), MultiInstances = false, Style = Shell::VsDockStyle.Tabbed, Orientation = Shell::ToolWindowOrientation.Right, Window = "{3AE79031-E1BC-11D0-8F78-00A0C9110057}")]
    [Shell::ProvideToolWindowVisibility(typeof(LWC2012ExplorerToolWindow), Constants.EditorFactoryId)]
    [Shell::ProvideToolWindow(typeof(LWC2012DetailsToolWindow), MultiInstances = false, Style = Shell::VsDockStyle.Tabbed, Orientation = Shell::ToolWindowOrientation.Bottom, Window = "{4A9B7E51-AA16-11D0-A8C5-00A0C921A4D2}")]
    [Shell::ProvideToolWindowVisibility(typeof(LWC2012DetailsToolWindow), Constants.EditorFactoryId)]
    [Shell::ProvideEditorFactory(typeof(LWC2012EditorFactory), 103, TrustLevel = Interop::__VSEDITORTRUSTLEVEL.ETL_AlwaysTrusted)]
    [Shell::ProvideEditorExtension(typeof(LWC2012EditorFactory), Constants.FileExtension, 50)]
    [VSHost::ProvideDirectiveProcessor(typeof(LWC2012DirectiveProcessor), LWC2012DirectiveProcessor.DirectiveProcessorName, "A default directive processor that provides access to LWC2012 files")]
    [global::System.Runtime.InteropServices.ComVisible(true)]
    public abstract class LWC2012PackageBase : SDesign::SDesignPackage
    {
        #region Override Methods
        
        protected override void Initialize()
        {
            base.Initialize();
            this.ComponentsProvider = new LWC2012ComponentsProvider();
            this.ModelSerializer = LWC2012Model::LWC2012Serializer.CreateNewInstance();
            this.ModelCopier = LWC2012Model::LWC2012Copier.CreateNewInstance();
            new LWC2012CommandSet().Initialize();
        
            using (LWC2012EditorFactory editorFactory = new LWC2012EditorFactory())
            {
                this.RegisterEditorFactory(editorFactory);
            }
        }
        
		protected override string GetModelName()
        {
            return "LWC2012";
        }
		
        protected override string GetWindowPaneName()
        {
            return "LWC2012";
        }
        
        protected override SDesign::SDesignExplorerToolWindow GetExplorerToolWindow()
        {
            return this.FindToolWindow(typeof(LWC2012ExplorerToolWindow), 0, true) as SDesign::SDesignExplorerToolWindow;
        }
        
        protected override SDesign::SDesignDetailsToolWindow GetDetailsToolWindow()
        {
            return this.FindToolWindow(typeof(LWC2012DetailsToolWindow), 0, true) as SDesign::SDesignDetailsToolWindow;
        }
        
        #endregion
    }
}