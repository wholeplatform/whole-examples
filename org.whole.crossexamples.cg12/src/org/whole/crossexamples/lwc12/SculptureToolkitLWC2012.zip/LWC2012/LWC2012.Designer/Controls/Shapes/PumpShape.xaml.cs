namespace LWC2012.Designer
{
    public partial class PumpShape : global::System.Windows.Controls.UserControl
    {
        public PumpShape()
        {
            InitializeComponent();
        }
    }
}