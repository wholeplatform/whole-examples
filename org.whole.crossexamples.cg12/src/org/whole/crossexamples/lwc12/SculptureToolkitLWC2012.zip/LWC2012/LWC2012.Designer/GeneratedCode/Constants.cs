namespace LWC2012.Designer
{
    public static partial class Constants
    {
        public const string LanguageName = "LWC2012";
        public const string FileExtension = ".lwc";
    }
}