namespace LWC2012.Model
{
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    public interface IPIDiagram : INamedElement
    {
        #region Properties

        global::System.Int32 RequestedTemperature { get; set;  }

        global::System.Int32 RoomTemperature { get; set;  }

        #endregion        
        
        #region References
        
        CommonModel::DomainCollection<IConnectableElement> Elements { get; }

        CommonModel::DomainCollection<IPipe> Pipes { get; }

        #endregion        
    }    
}