namespace LWC2012.Designer
{
    public partial class BoilerShape : global::System.Windows.Controls.UserControl
    {
        public BoilerShape()
        {
            InitializeComponent();
        }
    }
}