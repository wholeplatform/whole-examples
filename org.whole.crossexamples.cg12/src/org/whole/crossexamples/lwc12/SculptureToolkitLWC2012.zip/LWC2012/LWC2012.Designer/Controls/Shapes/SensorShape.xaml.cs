namespace LWC2012.Designer
{
    public partial class SensorShape : global::System.Windows.Controls.UserControl
    {
        public SensorShape()
        {
            InitializeComponent();
        }
    }
}