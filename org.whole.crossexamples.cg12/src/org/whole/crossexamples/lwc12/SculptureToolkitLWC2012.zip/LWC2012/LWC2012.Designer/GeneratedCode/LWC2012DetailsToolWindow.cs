namespace LWC2012.Designer
{
    using SDesign = Modelingsoft.Sculpture.SDesign.Common;

    [global::System.Runtime.InteropServices.Guid(Constants.DetailsWindowId)]
    internal partial class LWC2012DetailsToolWindow : LWC2012DetailsToolWindowBase
    {
        #region Constructors
        
        public LWC2012DetailsToolWindow()
            : base()
        {
        }
        
        #endregion
    }
    
    internal abstract class LWC2012DetailsToolWindowBase : SDesign::SDesignDetailsToolWindow
    {
        #region Constructors
        
        protected LWC2012DetailsToolWindowBase()
            : base()
        {
        }
        
        #endregion
        
        #region Override Properties
        
        protected override string WindowTitle
        {
            get
            {
                return "LWC2012 Details";
            }
        }

        protected override int BitmapResource
        {
            get
            {
                return 202;
            }
        }
        
        #endregion
        
        #region Override Methods
        
        protected override global::System.Windows.FrameworkElement CreateControl()
        {
            return new LWC2012Details();
        }
        
        #endregion
    }
}