namespace LWC2012.Model
{
    using System.Linq;
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    internal partial class Radiator : RadiatorBase
    {
        #region Constructors
        
        protected internal Radiator(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel)
            : base(domainObjectId, domainClass, domainModel)
        {
        }
        
        #endregion        
    }
    
    internal abstract class RadiatorBase : ConnectableElement, IRadiator
    {
        #region Events Args
        
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs RequestHeatPropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("RequestHeat");
        protected static readonly CommonModel::ModelChangedEventArgs RequestHeatModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"RequestHeat");     
    
        #endregion

        #region Private Variables
        
        private global::System.Boolean requestHeat;

        #endregion
        
        #region Constructors
        
        protected internal RadiatorBase(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel) 
            : base(domainObjectId, domainClass, domainModel)
        {
            if (typeof(Radiator) == this.GetType())
            {
                this.OnCreated();
            }
        }

        #endregion

        #region Features

        #region Properties
 
        public global::System.Boolean RequestHeat
        {
             get
             {
                return this.requestHeat;
             }
             
             set
             {
                 if (value != this.requestHeat)
                {
                    this.OnRequestHeatChanging(value);
                    RequestHeatModelEventArgs.OldValue = this.requestHeat;
                    this.requestHeat = value;
                    RequestHeatModelEventArgs.NewValue = this.requestHeat;
                    this.OnModelChanged(RequestHeatModelEventArgs, RequestHeatPropertyEventArgs);
                    this.OnRequestHeatChanged();
                 }
            }
        }

        #endregion

        #endregion

        #region IDomainObject Members
        
        public override object Get(CommonModel::IDomainFeature feature)
        {
            switch (feature.Name)
            {
                case "RequestHeat":
                    return this.RequestHeat;
                default:
                    return base.Get(feature);
            }
        }
        
        public override void Set(CommonModel::IDomainFeature feature, object newValue)
        {
            switch (feature.Name)
            {
                case "RequestHeat":
                    this.RequestHeat = (global::System.Boolean)newValue;
                    break;
                default:
                    base.Set(feature, newValue);
                    break;
            }
        }
        
        #endregion

        #region Extensibility Methods
        
        protected virtual void OnRequestHeatChanging(global::System.Boolean requestHeat) 
        { 
        }
    
        protected virtual void OnRequestHeatChanged() 
        { 
        }

        #endregion
    }
}