namespace LWC2012.Model
{
    using System.Linq;
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    internal partial class SystemEnd : SystemEndBase
    {
        #region Constructors
        
        protected internal SystemEnd(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel)
            : base(domainObjectId, domainClass, domainModel)
        {
        }
        
        #endregion        
    }
    
    internal abstract class SystemEndBase : ConnectableElement, ISystemEnd
    {
        #region Events Args
        
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs DirectionPropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("Direction");
        protected static readonly CommonModel::ModelChangedEventArgs DirectionModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"Direction");     
    
        #endregion

        #region Private Variables
        
        private SystemEndDirection direction;

        #endregion
        
        #region Constructors
        
        protected internal SystemEndBase(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel) 
            : base(domainObjectId, domainClass, domainModel)
        {
            if (typeof(SystemEnd) == this.GetType())
            {
                this.OnCreated();
            }
        }

        #endregion

        #region Features

        #region Properties
 
        public SystemEndDirection Direction
        {
             get
             {
                return this.direction;
             }
             
             set
             {
                 if (value != this.direction)
                {
                    this.OnDirectionChanging(value);
                    DirectionModelEventArgs.OldValue = this.direction;
                    this.direction = value;
                    DirectionModelEventArgs.NewValue = this.direction;
                    this.OnModelChanged(DirectionModelEventArgs, DirectionPropertyEventArgs);
                    this.OnDirectionChanged();
                 }
            }
        }

        #endregion

        #endregion

        #region IDomainObject Members
        
        public override object Get(CommonModel::IDomainFeature feature)
        {
            switch (feature.Name)
            {
                case "Direction":
                    return this.Direction;
                default:
                    return base.Get(feature);
            }
        }
        
        public override void Set(CommonModel::IDomainFeature feature, object newValue)
        {
            switch (feature.Name)
            {
                case "Direction":
                    this.Direction = (SystemEndDirection)newValue;
                    break;
                default:
                    base.Set(feature, newValue);
                    break;
            }
        }
        
        #endregion

        #region Extensibility Methods
        
        protected virtual void OnDirectionChanging(SystemEndDirection direction) 
        { 
        }
    
        protected virtual void OnDirectionChanged() 
        { 
        }

        #endregion
    }
}