﻿namespace LWC2012.Model
{
    using System.Linq;

    internal partial class Burner
    {
        protected override void OnIsOnChanged()
        {
            base.OnIsOnChanged();
            foreach (var pump in this.ConnectedElements.OfType<IPump>())
            {
                pump.IsOn = this.IsOn;
            }
        }
    }
}
