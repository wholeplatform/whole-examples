namespace LWC2012.Model
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Modelingsoft.Sculpture.SModel.Common;

    internal partial class SystemEnd
    {
        protected override IEnumerable<ViolationRule> GetViolationRules()
        {
            List<ViolationRule> violationRules = new List<ViolationRule>(base.GetViolationRules());

            var connectedPipes = this.DomainModel.Locate<IPipe>().
                                    Where(P => P.PipeIn == this || P.PipesOut.Contains(this));

            if (1 != connectedPipes.Count())
            {
                violationRules.Add(new ViolationRule(this,
                    string.Format("System End '{0}' must has 1 connection point.", this.Name),
                    ViolationType.Error));
            }

            return violationRules;
        }
    }
}