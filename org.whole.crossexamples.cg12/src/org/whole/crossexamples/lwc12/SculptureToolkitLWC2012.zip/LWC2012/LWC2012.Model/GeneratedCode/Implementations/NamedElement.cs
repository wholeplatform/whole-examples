namespace LWC2012.Model
{
    using System.Linq;
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    internal partial class NamedElement : NamedElementBase
    {
        #region Constructors
        
        protected internal NamedElement(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel)
            : base(domainObjectId, domainClass, domainModel)
        {
        }
        
        #endregion        
    }
    
    internal abstract class NamedElementBase : CommonModel::DomainObject, INamedElement
    {
        #region Events Args
        
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs NamePropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("Name");
        protected static readonly CommonModel::ModelChangedEventArgs NameModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"Name");     
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs DescriptionPropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("Description");
        protected static readonly CommonModel::ModelChangedEventArgs DescriptionModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"Description");     
    
        #endregion

        #region Private Variables
        
        private global::System.String name;
        private global::System.String description;

        #endregion
        
        #region Constructors
        
        protected internal NamedElementBase(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel) 
            : base(domainObjectId, domainClass, domainModel)
        {
            if (typeof(NamedElement) == this.GetType())
            {
                this.OnCreated();
            }
        }

        #endregion

        #region Features

        #region Properties
 
        public global::System.String Name
        {
             get
             {
                return this.name;
             }
             
             set
             {
                 if (value != this.name)
                {
                    this.OnNameChanging(value);
                    NameModelEventArgs.OldValue = this.name;
                    this.name = value;
                    NameModelEventArgs.NewValue = this.name;
                    this.OnModelChanged(NameModelEventArgs, NamePropertyEventArgs);
                    this.OnNameChanged();
                 }
            }
        }
 
        public global::System.String Description
        {
             get
             {
                return this.description;
             }
             
             set
             {
                 if (value != this.description)
                {
                    this.OnDescriptionChanging(value);
                    DescriptionModelEventArgs.OldValue = this.description;
                    this.description = value;
                    DescriptionModelEventArgs.NewValue = this.description;
                    this.OnModelChanged(DescriptionModelEventArgs, DescriptionPropertyEventArgs);
                    this.OnDescriptionChanged();
                 }
            }
        }

        #endregion

        #endregion

        #region IDomainObject Members
        
        public override object Get(CommonModel::IDomainFeature feature)
        {
            switch (feature.Name)
            {
                case "Name":
                    return this.Name;
                case "Description":
                    return this.Description;
                default:
                    return base.Get(feature);
            }
        }
        
        public override void Set(CommonModel::IDomainFeature feature, object newValue)
        {
            switch (feature.Name)
            {
                case "Name":
                    this.Name = (global::System.String)newValue;
                    break;
                case "Description":
                    this.Description = (global::System.String)newValue;
                    break;
                default:
                    base.Set(feature, newValue);
                    break;
            }
        }
        
        #endregion

        #region Override Methods
        
        public override string ToString()
        {
            return this.DomainModel.DomainFactory.ConvertToString(this.Name, typeof(global::System.String));
        }
        
        #endregion

        #region Extensibility Methods
        
        protected virtual void OnNameChanging(global::System.String name) 
        { 
        }
    
        protected virtual void OnNameChanged() 
        { 
        }
        
        protected virtual void OnDescriptionChanging(global::System.String description) 
        { 
        }
    
        protected virtual void OnDescriptionChanged() 
        { 
        }

        #endregion
    }
}