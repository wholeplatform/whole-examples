namespace LWC2012.Designer
{
    public partial class ValveShape : global::System.Windows.Controls.UserControl
    {
        public ValveShape()
        {
            InitializeComponent();
        }
    }
}