﻿namespace LWC2012.Designer
{
    using System;
    using System.Windows;
    using System.Windows.Data;

    [ValueConversion(typeof(bool?), typeof(Visibility))]
    public class VisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (null == ((bool?)value) || false == ((bool?)value))
            {
                return Visibility.Hidden;
            }

            return Visibility.Visible;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (Visibility.Visible == ((Visibility)value))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}