namespace LWC2012.Model
{
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    public interface IConnectableElement : INamedElement
    {
       #region References
        
        CommonModel::ReadOnlyDomainCollection<IConnectableElement> ConnectedElements { get; }

        #endregion        
    }    
}