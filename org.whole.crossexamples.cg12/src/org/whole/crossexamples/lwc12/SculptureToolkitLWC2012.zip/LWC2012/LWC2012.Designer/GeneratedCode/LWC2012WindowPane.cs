namespace LWC2012.Designer
{
    using SDesign = Modelingsoft.Sculpture.SDesign.Common;
    using SDiagram = Modelingsoft.Sculpture.SDiagram.Model;
    using SModel = Modelingsoft.Sculpture.SModel.Common;
    using LWC2012Model = LWC2012.Model;
    
    internal partial class LWC2012WindowPane : LWC2012WindowPaneBase
    {
        #region Constructors
        
        public LWC2012WindowPane(global::System.Windows.FrameworkElement editorControl)
            : base(editorControl)
        {
        }
        
        #endregion
    }
    
    internal abstract class LWC2012WindowPaneBase : SDesign::SDesignWindowPane
    {
        #region Constructors
        
        protected LWC2012WindowPaneBase(global::System.Windows.FrameworkElement editorControl)
            : base(editorControl)
        {
        }
        
        #endregion
        
        #region SDesignWindowPane Members

        protected override string GetFactoryId()
        {
            return Constants.EditorFactoryId;
        }

        #endregion
    }
}