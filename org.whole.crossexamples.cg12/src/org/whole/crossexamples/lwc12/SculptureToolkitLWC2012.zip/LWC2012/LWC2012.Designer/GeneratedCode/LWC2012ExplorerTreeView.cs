namespace LWC2012.Designer
{
    using SDesign = Modelingsoft.Sculpture.SDesign.Common;
    
    public partial class LWC2012ExplorerTreeView : SDesign::SDesignTreeView
    {
    }
}