﻿namespace LWC2012.Designer
{
    using Modelingsoft.Sculpture.SModel.Common;
    using LWC2012.Model;
    using System.Linq;

    public partial class PipeConnector
    {
        public override bool CanAcceptSource(IDomainObject source)
        {
            return source is IConnectableElement;
        }

        public override bool CanAcceptSourceAndTarget(IDomainObject source, IDomainObject target)
        {
            return target is IConnectableElement;
        }

        public override IDomainObject Connect(IDomainObject source, IDomainObject target)
        {
            var pipe = source.DomainModel.DomainFactory.Create<IPipe>();
            pipe.Name = "Pipe" + source.DomainModel.Locate<IPipe>().Count();
            ((IPIDiagram)source.DomainModel.Root).Pipes.Add(pipe);

            pipe.PipeIn = source as IConnectableElement;
            pipe.PipesOut.Add((IConnectableElement)target);

            return pipe;
        }
    }
}