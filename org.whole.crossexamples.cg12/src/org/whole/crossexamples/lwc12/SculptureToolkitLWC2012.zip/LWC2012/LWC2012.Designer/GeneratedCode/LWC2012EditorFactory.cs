namespace LWC2012.Designer
{
    using SDesign = Modelingsoft.Sculpture.SDesign.Common;
    
    [global::System.Runtime.InteropServices.Guid(Constants.EditorFactoryId)]
    internal partial class LWC2012EditorFactory : LWC2012EditorFactoryBase
    {
        #region Constructors
        
        public LWC2012EditorFactory()
            : base()
        {
        }
        
        #endregion
    }
    
    internal abstract class LWC2012EditorFactoryBase : SDesign::SDesignEditorFactory
    {
        #region Constructors
        
        protected LWC2012EditorFactoryBase()
            : base(Constants.EditorFactoryId)
        {
        }
        
        #endregion
        
        #region Override Methods
        
        protected override global::System.Windows.FrameworkElement CreateEditorControl()
        {
            return new LWC2012Designer();
        }
        
        protected override SDesign::SDesignWindowPane CreateWindowPane()
        {
            return new LWC2012WindowPane(this.CreateEditorControl());
        }
        
        #endregion
    }
}