namespace LWC2012.Designer
{
    using SDesign = Modelingsoft.Sculpture.SDesign.Common;
    using SModel = Modelingsoft.Sculpture.SModel.Common;
    
    public partial class LWC2012ComponentsProvider : LWC2012ComponentsProviderBase
    {
    }
    
    public abstract class LWC2012ComponentsProviderBase : SDesign::ComponentsProvider
    {
        #region Private Variables
        
        private global::System.Collections.Generic.Dictionary<string, SDesign::ConnectionBuilder> connectors;
        
        #endregion
        
        #region Override Methods
        
        public override bool HasShape(string domainClassName)
        {
            switch (domainClassName)
            {
                case "Pipe":
                case "Boiler":
                case "Burner":
                case "Pump":
                case "Radiator":
                case "Sensor":
                case "SystemEnd":
                case "Valve":
                    return true;
                default:
                    return false;
            }
        }
        
        public override global::System.Windows.FrameworkElement CreateShapeControl(SModel::IDomainClass domainClass)
        {
            switch (domainClass.Name)
            {
                case "Pipe":
                    return new PipeShape();
                case "Boiler":
                    return new BoilerShape();
                case "Burner":
                    return new BurnerShape();
                case "Pump":
                    return new PumpShape();
                case "Radiator":
                    return new RadiatorShape();
                case "Sensor":
                    return new SensorShape();
                case "SystemEnd":
                    return new SystemEndShape();
                case "Valve":
                    return new ValveShape();
                default:
                    return null;
            }
        }
        
        public override SDesign::SizingStyle GetShapeSizingStyle(SModel::IDomainClass domainClass)
        {
            switch (domainClass.Name)
            {
                case "Pipe":
                    return SDesign::SizingStyle.Both;
                case "Boiler":
                    return SDesign::SizingStyle.Both;
                case "Burner":
                    return SDesign::SizingStyle.Both;
                case "Pump":
                    return SDesign::SizingStyle.Both;
                case "Radiator":
                    return SDesign::SizingStyle.Both;
                case "Sensor":
                    return SDesign::SizingStyle.Both;
                case "SystemEnd":
                    return SDesign::SizingStyle.Both;
                case "Valve":
                    return SDesign::SizingStyle.Both;
                default:
                    return SDesign::SizingStyle.Both;
            }
        }
        
        public override global::System.Windows.FrameworkElement CreateConnectorControl(string connectorId)
        {
            switch (connectorId)
            {
                case "Pipe;PipeIn":
                    return new PipeInConnector();
                case "Pipe;PipesOut":
                    return new PipesOutConnector();
                default:
                    return null;
            }
        }
        
        public override global::System.Collections.Generic.Dictionary<string, SDesign::ConnectionBuilder> GetConnectors()
        {
            if (null == this.connectors)
            {
                this.connectors = new global::System.Collections.Generic.Dictionary<string, SDesign::ConnectionBuilder>();
                this.connectors.Add("Pipe;PipeIn", new PipeInConnectorBuilder());
                this.connectors.Add("Pipe;PipesOut", new PipesOutConnectorBuilder());
                this.connectors.Add("PipeConnector", new PipeConnector());
            }
            
            return this.connectors;
        }
        
        #endregion
    }
}