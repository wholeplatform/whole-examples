namespace LWC2012.Designer
{
    using System.Linq;
	using SDesign = Modelingsoft.Sculpture.SDesign.Common;
    using SModel = Modelingsoft.Sculpture.SModel.Common;
    using LWC2012Model = LWC2012.Model;

    public partial class PipesOutConnectorBuilder : PipesOutConnectorBuilderBase
    {
    }
    
    public abstract class PipesOutConnectorBuilderBase : SDesign::ConnectionBuilder
    {
        #region Override Methods
        
        public override bool CanAcceptSource(SModel::IDomainObject source)
        {
            if (null == source)
            {
                return false;
            }
            else if (source is LWC2012Model::IPipe)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public override bool CanAcceptSourceAndTarget(SModel::IDomainObject source, SModel::IDomainObject target)
        {
            if (false == this.CanAcceptSource(source) || false == this.CanAcceptTarget(target))
            {
                return false;
            }
            
            return true;
        }

        public override SModel::IDomainObject Connect(SModel::IDomainObject source, SModel::IDomainObject target)
        {
            if (false == this.CanAcceptSourceAndTarget(source, target))
            {
                throw new global::System.Exception("Invalid Source or Target to be connected");
            }

            SDesign::ToolboxItem.SelectionService.SelectedItemId = "Pipe;PipesOut";
            ((LWC2012Model::IPipe)source).PipesOut.Add((LWC2012Model::IConnectableElement)target);
            return source;
        }
        
        public override void Disconnect(SModel::IDomainObject source, SModel::IDomainObject target)
        {
            ((LWC2012Model::IPipe)source).PipesOut.Remove((LWC2012Model::IConnectableElement)target);
        }
        
		public override SDesign::RoutingStyle GetRoutingStyle()
        {
            return SDesign::RoutingStyle.Rectilinear;
        }
		
        #endregion
		
		#region Protected Methods
        
        protected virtual bool CanAcceptTarget(SModel::IDomainObject target)
        {
            if (null == target)
            {
                return false;
            }
            else if (target is LWC2012Model::IConnectableElement)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
		
		#endregion
    }
}