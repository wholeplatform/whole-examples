﻿namespace LWC2012.Designer
{
    using System;
    using System.Windows.Data;

    [ValueConversion(typeof(string), typeof(string))]
    public class CompartmentTypeConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (null == value)
            {
                return "void";
            }
            else
            {
                return value.ToString();
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (null == value)
            {
                return "void";
            }
            else
            {
                return value;
            }
        }
    }
}