namespace LWC2012.Designer
{
    using SDesign = Modelingsoft.Sculpture.SDesign.Common;
    
    [global::System.Runtime.InteropServices.Guid(Constants.ExplorerWindowId)]
    internal partial class LWC2012ExplorerToolWindow : LWC2012ExplorerToolWindowBase
    {
        #region Constructors
        
        public LWC2012ExplorerToolWindow()
            : base()
        {
        }
        
        #endregion
    }
    
    internal abstract class LWC2012ExplorerToolWindowBase : SDesign::SDesignExplorerToolWindow
    {
        #region Constructors
        
        protected LWC2012ExplorerToolWindowBase()
            : base()
        {
        }
        
        #endregion
        
        #region Override Properties
        
        protected override string WindowTitle
        {
            get
            {
                return "LWC2012 Explorer";
            }
        }

        protected override int BitmapResource
        {
            get
            {
                return 201;
            }
        }
    
        #endregion
    
        #region Override Methods
        
        protected override global::System.Windows.FrameworkElement CreateControl()
        {
            return new LWC2012Explorer();
        }
        
        #endregion
    }
}