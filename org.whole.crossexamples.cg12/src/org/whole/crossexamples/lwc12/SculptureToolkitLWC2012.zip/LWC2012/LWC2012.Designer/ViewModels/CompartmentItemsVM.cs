﻿namespace LWC2012.Designer
{
    using System.Collections;
    using System.Collections.ObjectModel;
    using Modelingsoft.Sculpture.SModel.Common;

    public class CompartmentItemsVM : ObservableCollection<CompartmentItemVM>
    {
        #region Private Variables

        private IList itemsList;
        private bool suspendAddEvent = false;

        #endregion

        #region Constructors

        public CompartmentItemsVM(IList itemsList)
        {
            this.itemsList = itemsList;
            this.suspendAddEvent = true;
            foreach (IDomainObject domainObject in itemsList)
            {
                this.Add(new CompartmentItemVM(domainObject, this));
            }

            this.suspendAddEvent = false;
        }

        #endregion

        #region Override Methods

        protected override void InsertItem(int index, CompartmentItemVM item)
        {
            base.InsertItem(index, item);
            if (false == this.suspendAddEvent)
            {
                this.itemsList.Add(item.DomainObject);
            }
        }

        protected override void RemoveItem(int index)
        {
            base.RemoveItem(index);
            ((IDomainObject)this.itemsList[index]).Detach();
        }

        protected override void MoveItem(int oldIndex, int newIndex)
        {
            base.MoveItem(oldIndex, newIndex);
            IDomainObject domainObject = this.itemsList[oldIndex] as IDomainObject;
            this.itemsList.RemoveAt(oldIndex);
            this.itemsList.Insert(newIndex, domainObject);
        }

        #endregion
    }
}