namespace LWC2012.Model
{
    public enum ValveEnds
    {
        Two = 0,
        Three = 1,
    }
}