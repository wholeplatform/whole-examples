namespace LWC2012.Model
{
    using System.Linq;
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    internal partial class Pipe : PipeBase
    {
        #region Constructors
        
        protected internal Pipe(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel)
            : base(domainObjectId, domainClass, domainModel)
        {
        }
        
        #endregion        
    }
    
    internal abstract class PipeBase : NamedElement, IPipe
    {
        #region Events Args
        
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs DiameterPropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("Diameter");
        protected static readonly CommonModel::ModelChangedEventArgs DiameterModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"Diameter");     
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs LengthPropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("Length");
        protected static readonly CommonModel::ModelChangedEventArgs LengthModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"Length");     
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs PipeInPropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("PipeIn");
        protected static readonly CommonModel::ModelChangedEventArgs PipeInModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"PipeIn");
    
        #endregion

        #region Private Variables
        
        private global::System.Int32 diameter;
        private global::System.Int32 length;
        private IConnectableElement pipeIn;
        private CommonModel::DomainCollection<IConnectableElement> pipesOut;

        #endregion
        
        #region Constructors
        
        protected internal PipeBase(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel) 
            : base(domainObjectId, domainClass, domainModel)
        {
            this.pipesOut = new CommonModel::ReferenceCollection<IConnectableElement>(this, "PipesOut", false);
            if (typeof(Pipe) == this.GetType())
            {
                this.OnCreated();
            }
        }

        #endregion

        #region Features

        #region Properties
 
        public global::System.Int32 Diameter
        {
             get
             {
                return this.diameter;
             }
             
             set
             {
                 if (value != this.diameter)
                {
                    this.OnDiameterChanging(value);
                    DiameterModelEventArgs.OldValue = this.diameter;
                    this.diameter = value;
                    DiameterModelEventArgs.NewValue = this.diameter;
                    this.OnModelChanged(DiameterModelEventArgs, DiameterPropertyEventArgs);
                    this.OnDiameterChanged();
                 }
            }
        }
 
        public global::System.Int32 Length
        {
             get
             {
                return this.length;
             }
             
             set
             {
                 if (value != this.length)
                {
                    this.OnLengthChanging(value);
                    LengthModelEventArgs.OldValue = this.length;
                    this.length = value;
                    LengthModelEventArgs.NewValue = this.length;
                    this.OnModelChanged(LengthModelEventArgs, LengthPropertyEventArgs);
                    this.OnLengthChanged();
                 }
            }
        }

        #endregion

        #region References
        
        public IConnectableElement PipeIn
        {
            get
            {
                return this.pipeIn;
            }
            
            set
            {
                if (value != this.pipeIn)
                {  
                    this.OnPipeInChanging(value);
                    PipeInModelEventArgs.OldValue = this.pipeIn;
                    this.pipeIn = value;
                    PipeInModelEventArgs.NewValue = this.pipeIn;
                    this.OnModelChanged(PipeInModelEventArgs, PipeInPropertyEventArgs);
                    this.OnPipeInChanged();
                }
            }
        }
        
        public CommonModel::DomainCollection<IConnectableElement> PipesOut
        {
            get
            {
                return this.pipesOut;
            }
        }

        #endregion

        #endregion

        #region IDomainObject Members
        
        public override object Get(CommonModel::IDomainFeature feature)
        {
            switch (feature.Name)
            {
                case "Diameter":
                    return this.Diameter;
                case "Length":
                    return this.Length;
                case "PipeIn":
                    return this.PipeIn;
                case "PipesOut":
                    return this.PipesOut;
                default:
                    return base.Get(feature);
            }
        }
        
        public override void Set(CommonModel::IDomainFeature feature, object newValue)
        {
            switch (feature.Name)
            {
                case "Diameter":
                    this.Diameter = (global::System.Int32)newValue;
                    break;
                case "Length":
                    this.Length = (global::System.Int32)newValue;
                    break;
                case "PipeIn":
                    this.PipeIn = (ConnectableElement)newValue;
                    break;
                case "PipesOut":
                    this.PipesOut.Add((ConnectableElement)newValue);
                    break;
                default:
                    base.Set(feature, newValue);
                    break;
            }
        }
        
        #endregion

        #region Extensibility Methods
        
        protected virtual void OnDiameterChanging(global::System.Int32 diameter) 
        { 
        }
    
        protected virtual void OnDiameterChanged() 
        { 
        }
        
        protected virtual void OnLengthChanging(global::System.Int32 length) 
        { 
        }
    
        protected virtual void OnLengthChanged() 
        { 
        }
        
        protected virtual void OnPipeInChanging(IConnectableElement pipeIn) 
        { 
        }
    
        protected virtual void OnPipeInChanged() 
        { 
        }

        #endregion
    }
}