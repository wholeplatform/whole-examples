﻿namespace Modelingsoft.SculptureToolkit.LWC2012.Designer.Controls
{
    using System.Windows;
    using System.Windows.Controls;

    public partial class Thermostat : UserControl
    {
        public Thermostat()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(this.Thermostat_Loaded);
        }

        private void Thermostat_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            if (null != LWC2012Package.Instance)
            {
                this.MainGrid.DataContext = LWC2012Package.Instance.Model.Root;
            }
        }
    }
}