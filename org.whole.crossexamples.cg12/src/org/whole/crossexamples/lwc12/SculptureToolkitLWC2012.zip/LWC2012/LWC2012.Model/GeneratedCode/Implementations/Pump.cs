namespace LWC2012.Model
{
    using System.Linq;
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    internal partial class Pump : PumpBase
    {
        #region Constructors
        
        protected internal Pump(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel)
            : base(domainObjectId, domainClass, domainModel)
        {
        }
        
        #endregion        
    }
    
    internal abstract class PumpBase : ConnectableElement, IPump
    {
        #region Events Args
        
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs IsOnPropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("IsOn");
        protected static readonly CommonModel::ModelChangedEventArgs IsOnModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"IsOn");     
    
        #endregion

        #region Private Variables
        
        private global::System.Boolean isOn;

        #endregion
        
        #region Constructors
        
        protected internal PumpBase(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel) 
            : base(domainObjectId, domainClass, domainModel)
        {
            this.isOn = false;
            if (typeof(Pump) == this.GetType())
            {
                this.OnCreated();
            }
        }

        #endregion

        #region Features

        #region Properties
 
        public global::System.Boolean IsOn
        {
             get
             {
                return this.isOn;
             }
             
             set
             {
                 if (value != this.isOn)
                {
                    this.OnIsOnChanging(value);
                    IsOnModelEventArgs.OldValue = this.isOn;
                    this.isOn = value;
                    IsOnModelEventArgs.NewValue = this.isOn;
                    this.OnModelChanged(IsOnModelEventArgs, IsOnPropertyEventArgs);
                    this.OnIsOnChanged();
                 }
            }
        }

        #endregion

        #endregion

        #region IDomainObject Members
        
        public override object Get(CommonModel::IDomainFeature feature)
        {
            switch (feature.Name)
            {
                case "IsOn":
                    return this.IsOn;
                default:
                    return base.Get(feature);
            }
        }
        
        public override void Set(CommonModel::IDomainFeature feature, object newValue)
        {
            switch (feature.Name)
            {
                case "IsOn":
                    this.IsOn = (global::System.Boolean)newValue;
                    break;
                default:
                    base.Set(feature, newValue);
                    break;
            }
        }
        
        #endregion

        #region Extensibility Methods
        
        protected virtual void OnIsOnChanging(global::System.Boolean isOn) 
        { 
        }
    
        protected virtual void OnIsOnChanged() 
        { 
        }

        #endregion
    }
}