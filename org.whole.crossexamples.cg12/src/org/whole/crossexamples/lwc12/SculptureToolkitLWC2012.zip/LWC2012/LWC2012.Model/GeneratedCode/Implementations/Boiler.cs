namespace LWC2012.Model
{
    using System.Linq;
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    internal partial class Boiler : BoilerBase
    {
        #region Constructors
        
        protected internal Boiler(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel)
            : base(domainObjectId, domainClass, domainModel)
        {
        }
        
        #endregion        
    }
    
    internal abstract class BoilerBase : ConnectableElement, IBoiler
    {
        #region Events Args
        
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs TemperaturePropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("Temperature");
        protected static readonly CommonModel::ModelChangedEventArgs TemperatureModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"Temperature");     
    
        #endregion

        #region Private Variables
        
        private global::System.Int32 temperature;

        #endregion
        
        #region Constructors
        
        protected internal BoilerBase(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel) 
            : base(domainObjectId, domainClass, domainModel)
        {
            if (typeof(Boiler) == this.GetType())
            {
                this.OnCreated();
            }
        }

        #endregion

        #region Features

        #region Properties
 
        public global::System.Int32 Temperature
        {
             get
             {
                return this.temperature;
             }
             
             set
             {
                 if (value != this.temperature)
                {
                    this.OnTemperatureChanging(value);
                    TemperatureModelEventArgs.OldValue = this.temperature;
                    this.temperature = value;
                    TemperatureModelEventArgs.NewValue = this.temperature;
                    this.OnModelChanged(TemperatureModelEventArgs, TemperaturePropertyEventArgs);
                    this.OnTemperatureChanged();
                 }
            }
        }

        #endregion

        #endregion

        #region IDomainObject Members
        
        public override object Get(CommonModel::IDomainFeature feature)
        {
            switch (feature.Name)
            {
                case "Temperature":
                    return this.Temperature;
                default:
                    return base.Get(feature);
            }
        }
        
        public override void Set(CommonModel::IDomainFeature feature, object newValue)
        {
            switch (feature.Name)
            {
                case "Temperature":
                    this.Temperature = (global::System.Int32)newValue;
                    break;
                default:
                    base.Set(feature, newValue);
                    break;
            }
        }
        
        #endregion

        #region Extensibility Methods
        
        protected virtual void OnTemperatureChanging(global::System.Int32 temperature) 
        { 
        }
    
        protected virtual void OnTemperatureChanged() 
        { 
        }

        #endregion
    }
}