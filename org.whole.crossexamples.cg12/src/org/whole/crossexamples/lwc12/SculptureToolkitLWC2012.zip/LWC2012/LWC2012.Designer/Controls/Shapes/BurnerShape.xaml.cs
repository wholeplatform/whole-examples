namespace LWC2012.Designer
{
    public partial class BurnerShape : global::System.Windows.Controls.UserControl
    {
        public BurnerShape()
        {
            InitializeComponent();
        }
    }
}