namespace LWC2012.Model
{
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    public interface ISensor : IConnectableElement
    {
        #region Properties

        SensorType Type { get; set;  }

        global::System.Int32 Degree { get; set;  }

        #endregion        
    }    
}