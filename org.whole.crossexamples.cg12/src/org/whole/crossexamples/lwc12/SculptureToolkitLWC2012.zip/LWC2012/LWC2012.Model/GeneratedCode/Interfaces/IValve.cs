namespace LWC2012.Model
{
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    public interface IValve : IConnectableElement
    {
        #region Properties

        ValveEnds Ends { get; set;  }

        ValveType Type { get; set;  }

        ValveStatus Status { get; set;  }

        #endregion        
    }    
}