namespace LWC2012.Model
{
    using System.Linq;
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    internal partial class PIDiagram : PIDiagramBase
    {
        #region Constructors
        
        protected internal PIDiagram(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel)
            : base(domainObjectId, domainClass, domainModel)
        {
        }
        
        #endregion        
    }
    
    internal abstract class PIDiagramBase : NamedElement, IPIDiagram
    {
        #region Events Args
        
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs RequestedTemperaturePropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("RequestedTemperature");
        protected static readonly CommonModel::ModelChangedEventArgs RequestedTemperatureModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"RequestedTemperature");     
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs RoomTemperaturePropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("RoomTemperature");
        protected static readonly CommonModel::ModelChangedEventArgs RoomTemperatureModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"RoomTemperature");     
    
        #endregion

        #region Private Variables
        
        private global::System.Int32 requestedTemperature;
        private global::System.Int32 roomTemperature;
        private CommonModel::DomainCollection<IConnectableElement> elements;
        private CommonModel::DomainCollection<IPipe> pipes;

        #endregion
        
        #region Constructors
        
        protected internal PIDiagramBase(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel) 
            : base(domainObjectId, domainClass, domainModel)
        {
            this.elements = new CommonModel::ReferenceCollection<IConnectableElement>(this, "Elements", true);
            this.pipes = new CommonModel::ReferenceCollection<IPipe>(this, "Pipes", true);
            if (typeof(PIDiagram) == this.GetType())
            {
                this.OnCreated();
            }
        }

        #endregion

        #region Features

        #region Properties
 
        public global::System.Int32 RequestedTemperature
        {
             get
             {
                return this.requestedTemperature;
             }
             
             set
             {
                 if (value != this.requestedTemperature)
                {
                    this.OnRequestedTemperatureChanging(value);
                    RequestedTemperatureModelEventArgs.OldValue = this.requestedTemperature;
                    this.requestedTemperature = value;
                    RequestedTemperatureModelEventArgs.NewValue = this.requestedTemperature;
                    this.OnModelChanged(RequestedTemperatureModelEventArgs, RequestedTemperaturePropertyEventArgs);
                    this.OnRequestedTemperatureChanged();
                 }
            }
        }
 
        public global::System.Int32 RoomTemperature
        {
             get
             {
                return this.roomTemperature;
             }
             
             set
             {
                 if (value != this.roomTemperature)
                {
                    this.OnRoomTemperatureChanging(value);
                    RoomTemperatureModelEventArgs.OldValue = this.roomTemperature;
                    this.roomTemperature = value;
                    RoomTemperatureModelEventArgs.NewValue = this.roomTemperature;
                    this.OnModelChanged(RoomTemperatureModelEventArgs, RoomTemperaturePropertyEventArgs);
                    this.OnRoomTemperatureChanged();
                 }
            }
        }

        #endregion

        #region References
        
        public CommonModel::DomainCollection<IConnectableElement> Elements
        {
            get
            {
                return this.elements;
            }
        }
        
        public CommonModel::DomainCollection<IPipe> Pipes
        {
            get
            {
                return this.pipes;
            }
        }

        #endregion

        #endregion

        #region IDomainObject Members
        
        public override object Get(CommonModel::IDomainFeature feature)
        {
            switch (feature.Name)
            {
                case "RequestedTemperature":
                    return this.RequestedTemperature;
                case "RoomTemperature":
                    return this.RoomTemperature;
                case "Elements":
                    return this.Elements;
                case "Pipes":
                    return this.Pipes;
                default:
                    return base.Get(feature);
            }
        }
        
        public override void Set(CommonModel::IDomainFeature feature, object newValue)
        {
            switch (feature.Name)
            {
                case "RequestedTemperature":
                    this.RequestedTemperature = (global::System.Int32)newValue;
                    break;
                case "RoomTemperature":
                    this.RoomTemperature = (global::System.Int32)newValue;
                    break;
                case "Elements":
                    this.Elements.Add((ConnectableElement)newValue);
                    break;
                case "Pipes":
                    this.Pipes.Add((Pipe)newValue);
                    break;
                default:
                    base.Set(feature, newValue);
                    break;
            }
        }
        
        #endregion

        #region Extensibility Methods
        
        protected virtual void OnRequestedTemperatureChanging(global::System.Int32 requestedTemperature) 
        { 
        }
    
        protected virtual void OnRequestedTemperatureChanged() 
        { 
        }
        
        protected virtual void OnRoomTemperatureChanging(global::System.Int32 roomTemperature) 
        { 
        }
    
        protected virtual void OnRoomTemperatureChanged() 
        { 
        }

        #endregion
    }
}