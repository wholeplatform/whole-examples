namespace LWC2012.Designer
{
    using SDesign = Modelingsoft.Sculpture.SDesign.Common;
    using SDiagram = Modelingsoft.Sculpture.SDiagram.Model;

    public partial class LWC2012Designer : global::System.Windows.Controls.UserControl
    {
        #region Constructors

        public LWC2012Designer()
        {
            InitializeComponent();
            this.Loaded += new global::System.Windows.RoutedEventHandler(this.LWC2012Designer_Loaded);
        }

        #endregion

        #region Private Methods

        private void LWC2012Designer_Loaded(object sender, global::System.Windows.RoutedEventArgs e)
        {
			if (false == (this.DataContext is SDiagram::ISDiagramModel))
            {
                this.DataContext = LWC2012Package.Instance.DiagramModel.Root;
            }
        }

        #endregion
    }
}