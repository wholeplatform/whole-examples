﻿namespace MainMold
{
    public class BoilerTemplate : ConnectableElementTemplate
    {
    }

    public class BurnerTemplate : ConnectableElementTemplate
    {
    }

    public class PumpTemplate : ConnectableElementTemplate
    {
    }

    public class RadiatorTemplate : ConnectableElementTemplate
    {
    }

    public class SensorTemplate : ConnectableElementTemplate
    {
    }

    public class SystemEndTemplate : ConnectableElementTemplate
    {
    }

    public class ValveTemplate : ConnectableElementTemplate
    {
    }
}
