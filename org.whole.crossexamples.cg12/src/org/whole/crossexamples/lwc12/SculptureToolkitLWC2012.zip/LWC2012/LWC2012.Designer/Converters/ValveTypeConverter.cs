﻿namespace LWC2012.Designer
{
    using System;
    using System.Windows;
    using System.Windows.Data;
    using LWC2012.Model;

    [ValueConversion(typeof(ValveType?), typeof(Visibility))]
    public class ValveTypeConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (null == ((ValveType?)value) || ValveType.Manual == ((ValveType?)value))
            {
                return Visibility.Collapsed;                
            }

            return Visibility.Visible;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (Visibility.Visible == ((Visibility)value))
            {
                return ValveType.Control;
            }
            else
            {
                return ValveType.Manual;
            }
        }
    }
}