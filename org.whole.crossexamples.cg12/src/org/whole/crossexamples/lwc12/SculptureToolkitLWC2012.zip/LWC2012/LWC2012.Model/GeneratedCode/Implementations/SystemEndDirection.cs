namespace LWC2012.Model
{
    public enum SystemEndDirection
    {
        Source = 0,
        Exhaust = 1,
    }
}