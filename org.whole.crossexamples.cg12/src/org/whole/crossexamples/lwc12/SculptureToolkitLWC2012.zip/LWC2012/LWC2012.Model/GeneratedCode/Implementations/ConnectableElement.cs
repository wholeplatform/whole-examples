namespace LWC2012.Model
{
    using System.Linq;
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    internal partial class ConnectableElement : ConnectableElementBase
    {
        #region Constructors
        
        protected internal ConnectableElement(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel)
            : base(domainObjectId, domainClass, domainModel)
        {
        }
        
        #endregion        
    }
    
    internal abstract class ConnectableElementBase : NamedElement, IConnectableElement
    {
        #region Constructors
        
        protected internal ConnectableElementBase(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel) 
            : base(domainObjectId, domainClass, domainModel)
        {
            if (typeof(ConnectableElement) == this.GetType())
            {
                this.OnCreated();
            }
        }

        #endregion

        #region Features

        #region References
                
        public CommonModel::ReadOnlyDomainCollection<IConnectableElement> ConnectedElements
        {
            get
            {
                return this.OnGetConnectedElements();
            }
        }

        #endregion

        #endregion

        #region IDomainObject Members
        
        public override object Get(CommonModel::IDomainFeature feature)
        {
            switch (feature.Name)
            {
                case "ConnectedElements":
                    return this.ConnectedElements;
                default:
                    return base.Get(feature);
            }
        }
        
        public override void Set(CommonModel::IDomainFeature feature, object newValue)
        {
            switch (feature.Name)
            {
                default:
                    base.Set(feature, newValue);
                    break;
            }
        }
        
        #endregion

        #region Abstract Methods

        protected abstract CommonModel::ReadOnlyDomainCollection<IConnectableElement> OnGetConnectedElements();

        #endregion
    }
}