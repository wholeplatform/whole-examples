namespace LWC2012.Model
{
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    public interface IBoiler : IConnectableElement
    {
        #region Properties

        global::System.Int32 Temperature { get; set;  }

        #endregion        
    }    
}