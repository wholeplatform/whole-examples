namespace LWC2012.Designer
{
    public partial class LWC2012Details : global::System.Windows.Controls.UserControl
    {
        public LWC2012Details()
        {
            InitializeComponent();
        }
    }
}