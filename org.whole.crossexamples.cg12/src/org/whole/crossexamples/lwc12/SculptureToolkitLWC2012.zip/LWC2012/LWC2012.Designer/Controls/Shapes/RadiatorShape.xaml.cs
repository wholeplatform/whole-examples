namespace LWC2012.Designer
{
    public partial class RadiatorShape : global::System.Windows.Controls.UserControl
    {
        public RadiatorShape()
        {
            InitializeComponent();
        }
    }
}