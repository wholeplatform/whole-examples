namespace LWC2012.Designer
{
    public partial class SystemEndShape : global::System.Windows.Controls.UserControl
    {
        public SystemEndShape()
        {
            InitializeComponent();
        }
    }
}