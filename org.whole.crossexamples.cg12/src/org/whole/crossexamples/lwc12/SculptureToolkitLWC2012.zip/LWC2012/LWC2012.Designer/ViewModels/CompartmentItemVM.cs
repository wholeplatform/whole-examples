﻿namespace LWC2012.Designer
{
    using System.ComponentModel;
    using System.Linq;
    using System.Windows.Input;
    using Modelingsoft.Sculpture.SDesign.Cinch;
    using Modelingsoft.Sculpture.SModel.Common;

    public class CompartmentItemVM : ViewModelBase
    {
        #region Private Variables

        private CompartmentItemsVM parentList;

        #endregion

        #region Constructors

        public CompartmentItemVM(IDomainObject domainObject, CompartmentItemsVM parentList)
        {

            this.DomainObject = domainObject;

            this.IsTypedElement = null != domainObject.DomainClass.AllFeatures.FirstOrDefault(P => "Type" == P.Name);

            this.parentList = parentList;

            this.UpCommand = new SimpleCommand
            {
                CanExecuteDelegate = x => this.CanUp(),
                ExecuteDelegate = x => this.OnUp()
            };

            this.DownCommand = new SimpleCommand
            {
                CanExecuteDelegate = x => this.CanDown(),
                ExecuteDelegate = x => this.OnDown()
            };

            this.DeleteCommand = new SimpleCommand
            {
                CanExecuteDelegate = x => true,
                ExecuteDelegate = x => this.OnDelete()
            };
        }

        #endregion

        #region Public Properties

        public IDomainObject DomainObject { get; private set; }

        public bool IsTypedElement { get; private set; }

        public ICommand UpCommand { get; private set; }

        public ICommand DownCommand { get; private set; }

        public ICommand DeleteCommand { get; private set; }

        public string Name { get; set; }

        #endregion

        #region Command Methods

        private bool CanUp()
        {
            return 0 != this.parentList.Count && this != this.parentList.First();
        }

        private void OnUp()
        {
            int curIndex = this.parentList.IndexOf(this);
            this.parentList.Move(curIndex, curIndex - 1);
        }

        private bool CanDown()
        {
            return 0 != this.parentList.Count && this != this.parentList.Last();
        }

        private void OnDown()
        {
            int curIndex = this.parentList.IndexOf(this);
            this.parentList.Move(curIndex, curIndex + 1);
        }

        private void OnDelete()
        {
            this.parentList.Remove(this);
        }

        #endregion
    }
}