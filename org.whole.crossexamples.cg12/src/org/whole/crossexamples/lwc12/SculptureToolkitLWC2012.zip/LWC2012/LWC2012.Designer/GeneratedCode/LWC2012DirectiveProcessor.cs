namespace LWC2012.Designer
{
    using SGenerate = Modelingsoft.Sculpture.SGenerate.Common;
    using SModel = Modelingsoft.Sculpture.SModel.Common;
    using LWC2012Model = LWC2012.Model;
    
    public sealed partial class LWC2012DirectiveProcessor : LWC2012DirectiveProcessorBase
    {
    }

    public abstract class LWC2012DirectiveProcessorBase : SGenerate::SDesignDirectiveProcessor
    {
        #region Constant members

        public const string DirectiveProcessorName = "LWC2012DirectiveProcessor";

        #endregion

        #region SDesignDirectiveProcessor Members

        public override string ModelName
        {
            get { return "LWC2012"; }
        }

        protected override string FriendlyName
        {
            get { return DirectiveProcessorName; }
        }

        protected override string SupportedDirectiveName
        {
            get { return "LWC2012"; }
        }

        public override string[] GetImportsForProcessingRun()
        {
            global::System.Collections.Generic.List<string> imports = new global::System.Collections.Generic.List<string>(base.GetImportsForProcessingRun());
            imports.Add("LWC2012.Model");
            return imports.ToArray();
        }

        public override string[] GetReferencesForProcessingRun()
        {
            global::System.Collections.Generic.List<string> references = new global::System.Collections.Generic.List<string>(base.GetReferencesForProcessingRun());
            references.Add(typeof(LWC2012Model::LWC2012DomainModel).Assembly.Location);
            return references.ToArray();
        }

        #endregion
    }
}