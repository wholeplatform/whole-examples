namespace LWC2012.Designer
{
    using System.Windows.Controls;
    using System.Windows.Input;
    using System.Windows.Media;
    using Modelingsoft.Sculpture.SDesign.Common;
	
	public partial class PipeInConnector : Canvas, ISelectNotification
    {
        #region Private Methods

        private Brush defaultBrush;
        private Brush overBrush;
        private Brush defaultTextBrush;
        private Brush selectedBrush;
        private bool isSelected;

        #endregion

        #region Constructors

        public PipeInConnector()
        {
            InitializeComponent();
            this.defaultBrush = (Brush)this.Resources["DefaultBrush"];
            this.overBrush = (Brush)this.Resources["OverBrush"];
            this.defaultTextBrush = (Brush)this.Resources["DefaultTextBrush"];
            this.selectedBrush = (Brush)this.Resources["SelectedBrush"];
        }

        #endregion

        #region Public Methods

        public void OnSelectionChanged(bool isSelected)
        {
            this.isSelected = isSelected;
            if (true == this.isSelected)
            {
                this.MainPath.Stroke = this.selectedBrush;
            }
            else
            {
                this.MainPath.Stroke = this.defaultBrush;
            }
        }

        #endregion

        #region Override Methods

        protected override void OnMouseEnter(MouseEventArgs e)
        {
            base.OnMouseEnter(e);
            if (false == isSelected)
            {
                this.MainPath.Stroke = this.overBrush;
            }
        }

        protected override void OnMouseLeave(MouseEventArgs e)
        {
            base.OnMouseLeave(e);
            if (false == isSelected)
            {
                this.MainPath.Stroke = this.defaultBrush;
            }
        }

        #endregion
    }
}