namespace LWC2012.Model
{
    public enum ValveStatus
    {
        Left = 0,
        Right = 1,
        Both = 2,
        None = 3,
    }
}