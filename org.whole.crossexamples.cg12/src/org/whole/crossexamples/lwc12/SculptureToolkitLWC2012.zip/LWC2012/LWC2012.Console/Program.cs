﻿namespace LWC2012.Console
{
    using System;
    using System.Linq;
    using LWC2012.Model;

    class Program
    {
        static void Main(string[] args)
        {
            var diagram = LWC2012DomainModel.CreateNewInstance().Root as IPIDiagram;
            diagram.Name = "P&I Network";
            var factory = diagram.DomainModel.DomainFactory;

            var systemEnd = factory.Create<ISystemEnd>();
            systemEnd.Name = "Cold Water";
            diagram.Elements.Add(systemEnd);

            var boiler = factory.Create<IBoiler>();
            boiler.Name = "Boiler1";
            diagram.Elements.Add(boiler);

            var pipe = factory.Create<IPipe>();
            pipe.Name = "Pipe1";
            diagram.Pipes.Add(pipe);

            pipe.PipesOut.Add(boiler);

            diagram.Validate().ToList().ForEach(V => Console.WriteLine(V.Message));
        }
    }
}