namespace LWC2012.Model
{
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    public interface IPipe : INamedElement
    {
        #region Properties

        global::System.Int32 Diameter { get; set;  }

        global::System.Int32 Length { get; set;  }

        #endregion        
        
        #region References
        
        IConnectableElement PipeIn { get; set; }

        CommonModel::DomainCollection<IConnectableElement> PipesOut { get; }

        #endregion        
    }    
}