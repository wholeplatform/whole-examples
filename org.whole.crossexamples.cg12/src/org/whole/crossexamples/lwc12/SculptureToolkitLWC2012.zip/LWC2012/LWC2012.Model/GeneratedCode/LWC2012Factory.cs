namespace LWC2012.Model
{    
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;

    internal partial class LWC2012Factory : LWC2012FactoryBase
    {    
        #region Constructors
        
        protected internal LWC2012Factory(CommonModel::IDomainModel domainModel) 
            : base(domainModel)
        {
        }
        
        #endregion        
    }
    
    internal abstract class LWC2012FactoryBase : CommonModel::DomainFactory
    {    
        #region Constructors
        
        protected internal LWC2012FactoryBase(CommonModel::IDomainModel domainModel) 
            : base(domainModel)
        {
        }
        
        #endregion
        
        #region DomainFactory Members
        
        public override CommonModel::IDomainSerializer CreateDomainSerializer()
        {
           return LWC2012Serializer.CreateNewInstance();
        }

        public override CommonModel::IDomainCopier CreateDomainCopier()
        {
           return LWC2012Copier.CreateNewInstance();
        }

        public override CommonModel::IDomainComparer CreateDomainComparer()
        {
            return LWC2012Comparer.CreateNewInstance();
        } 
        
        #endregion
        
        #region Override Methods        

        protected override CommonModel::IDomainObject CreateDomainObject(CommonModel::IDomainClass domainClass, global::System.Guid domainObjectId)
        {
            CommonModel::IDomainObject domainObject = null;
            
            switch (domainClass.Name)
            {
                case "NamedElement":
                    domainObject = new NamedElement(domainObjectId, domainClass, this.DomainModel);
                    break;
                case "ConnectableElement":
                    domainObject = new ConnectableElement(domainObjectId, domainClass, this.DomainModel);
                    break;
                case "Pipe":
                    domainObject = new Pipe(domainObjectId, domainClass, this.DomainModel);
                    break;
                case "Boiler":
                    domainObject = new Boiler(domainObjectId, domainClass, this.DomainModel);
                    break;
                case "Burner":
                    domainObject = new Burner(domainObjectId, domainClass, this.DomainModel);
                    break;
                case "Pump":
                    domainObject = new Pump(domainObjectId, domainClass, this.DomainModel);
                    break;
                case "Radiator":
                    domainObject = new Radiator(domainObjectId, domainClass, this.DomainModel);
                    break;
                case "Sensor":
                    domainObject = new Sensor(domainObjectId, domainClass, this.DomainModel);
                    break;
                case "SystemEnd":
                    domainObject = new SystemEnd(domainObjectId, domainClass, this.DomainModel);
                    break;
                case "Valve":
                    domainObject = new Valve(domainObjectId, domainClass, this.DomainModel);
                    break;
                default:
                    break;
            }
            
            if (null == domainObject)
            {
                if (true == domainClass.IsRoot)
                {
                    throw new global::System.Exception("Cannot create instance from root DomainClass");
                }
                else if(true == domainClass.IsAbstract)
                {
                    throw new global::System.Exception("Cannot create instance from abstract DomainClass");
                }
                else
                {
                    throw new global::System.Exception("The Domain Class Not Found");
                }
            }

            return domainObject;
        }
        
        #endregion        
    }
}