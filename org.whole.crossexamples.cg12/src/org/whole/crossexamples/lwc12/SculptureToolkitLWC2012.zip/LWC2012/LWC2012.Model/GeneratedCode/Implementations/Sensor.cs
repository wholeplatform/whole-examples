namespace LWC2012.Model
{
    using System.Linq;
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    internal partial class Sensor : SensorBase
    {
        #region Constructors
        
        protected internal Sensor(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel)
            : base(domainObjectId, domainClass, domainModel)
        {
        }
        
        #endregion        
    }
    
    internal abstract class SensorBase : ConnectableElement, ISensor
    {
        #region Events Args
        
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs TypePropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("Type");
        protected static readonly CommonModel::ModelChangedEventArgs TypeModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"Type");     
        protected static readonly global::System.ComponentModel.PropertyChangedEventArgs DegreePropertyEventArgs = new global::System.ComponentModel.PropertyChangedEventArgs("Degree");
        protected static readonly CommonModel::ModelChangedEventArgs DegreeModelEventArgs = new CommonModel::ModelChangedEventArgs(featureName:"Degree");     
    
        #endregion

        #region Private Variables
        
        private SensorType type;
        private global::System.Int32 degree;

        #endregion
        
        #region Constructors
        
        protected internal SensorBase(global::System.Guid domainObjectId, CommonModel::IDomainClass domainClass, CommonModel::IDomainModel domainModel) 
            : base(domainObjectId, domainClass, domainModel)
        {
            if (typeof(Sensor) == this.GetType())
            {
                this.OnCreated();
            }
        }

        #endregion

        #region Features

        #region Properties
 
        public SensorType Type
        {
             get
             {
                return this.type;
             }
             
             set
             {
                 if (value != this.type)
                {
                    this.OnTypeChanging(value);
                    TypeModelEventArgs.OldValue = this.type;
                    this.type = value;
                    TypeModelEventArgs.NewValue = this.type;
                    this.OnModelChanged(TypeModelEventArgs, TypePropertyEventArgs);
                    this.OnTypeChanged();
                 }
            }
        }
 
        public global::System.Int32 Degree
        {
             get
             {
                return this.degree;
             }
             
             set
             {
                 if (value != this.degree)
                {
                    this.OnDegreeChanging(value);
                    DegreeModelEventArgs.OldValue = this.degree;
                    this.degree = value;
                    DegreeModelEventArgs.NewValue = this.degree;
                    this.OnModelChanged(DegreeModelEventArgs, DegreePropertyEventArgs);
                    this.OnDegreeChanged();
                 }
            }
        }

        #endregion

        #endregion

        #region IDomainObject Members
        
        public override object Get(CommonModel::IDomainFeature feature)
        {
            switch (feature.Name)
            {
                case "Type":
                    return this.Type;
                case "Degree":
                    return this.Degree;
                default:
                    return base.Get(feature);
            }
        }
        
        public override void Set(CommonModel::IDomainFeature feature, object newValue)
        {
            switch (feature.Name)
            {
                case "Type":
                    this.Type = (SensorType)newValue;
                    break;
                case "Degree":
                    this.Degree = (global::System.Int32)newValue;
                    break;
                default:
                    base.Set(feature, newValue);
                    break;
            }
        }
        
        #endregion

        #region Extensibility Methods
        
        protected virtual void OnTypeChanging(SensorType type) 
        { 
        }
    
        protected virtual void OnTypeChanged() 
        { 
        }
        
        protected virtual void OnDegreeChanging(global::System.Int32 degree) 
        { 
        }
    
        protected virtual void OnDegreeChanged() 
        { 
        }

        #endregion
    }
}