namespace LWC2012.Model
{
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
    
    public interface IRadiator : IConnectableElement
    {
        #region Properties

        global::System.Boolean RequestHeat { get; set;  }

        #endregion        
    }    
}