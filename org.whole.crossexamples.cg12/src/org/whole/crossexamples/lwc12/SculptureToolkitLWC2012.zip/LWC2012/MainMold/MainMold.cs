﻿namespace MainMold
{
    using System.Linq;
	using SModel = Modelingsoft.Sculpture.SModel.Common;
	using SGenerate = Modelingsoft.Sculpture.SGenerate.Common;
    using SDesign = Modelingsoft.Sculpture.SDesign.Common;
    using LWC2012Model = LWC2012.Model;
    
    [SModel::MoldComponent(typeof(SModel::IMold), MainMold.MoldName, MainMold.ModelName)]
    public partial class MainMold : SModel::Mold
    {
        #region Public constants
        
        public const string MoldName = "MainMold";
        public const string ModelName = "LWC2012";
        
        #endregion
        
        #region Override Properties
        
        public override string BaseMold
        {
            get { return string.Empty; }
        }

        public override string Name
        {
            get { return MoldName; }
        }

        public override string Version
        {
            get { return "1.0"; }
        }
        
        #endregion
    }

    [SModel::MoldComponent(typeof(SGenerate::ISGenerateMold), MainMold.MoldName, MainMold.ModelName)]
    public partial class MainMoldSGenerate : SGenerate::SGenerateMold
    {
        #region Override Properties
        
        protected override string MoldName
        {
            get { return MainMold.MoldName; }
        }

        protected override string ModelName
        {
            get { return MainMold.ModelName; }
        }
        
        #endregion
    }

    [SModel::MoldComponent(typeof(SDesign::ISDesignMold), MainMold.MoldName, MainMold.ModelName)]
    public partial class MainMoldSDesign : SDesign::SDesignMold
    {
        #region Override Properties
        
        protected override string MoldName
        {
            get { return MainMold.MoldName; }
        }

        protected override string ModelName
        {
            get { return MainMold.ModelName; }
        }
        
        #endregion
    }
    
    [SModel::MoldComponent(typeof(SGenerate::ITemplate), MainMold.MoldName, MainMold.ModelName)]
    public partial class DiagramTemplateTemplate : SGenerate::ITemplate
    {
        #region Private Variables

        private SGenerate::SGenerateTemplate template = new global::MainMold.DiagramTemplate();

        #endregion

        #region ITemplate Members
        
        public SGenerate::ISGenerateMold SGenerateMold { get; set; }
        
        public SGenerate::SGenerateTemplate Template
        {
            get { return this.template; }
        }

        public global::System.Type AppliedTo
        {
            get { return typeof(LWC2012Model::IPIDiagram); }
        }

        public string OutputProjectPattern
        {
            get { return @"WebDocument"; }
        }

        public string OutputPattern
        {
            get { return @"Index.htm"; }
        }

        public SGenerate::IOutputCondition OutputCondition
        {
            get { return null; }
        }

        public SGenerate::BuildAction? BuildAction
        {
            get { return null; }
        }

        public bool Overwrite
        {
            get { return true; }
        }

        public bool OutputToSingleFile
        {
            get { return false; }
        }

        public string CustomTool
        {
            get { return null; }
        }

        public string CustomToolNamespace
        {
            get { return null; }
        }

        public global::System.Type SubItemOf
        {
            get { return null; }
        }

        public global::System.Text.Encoding Encoding
        {
            get { return global::System.Text.Encoding.ASCII; }
        }

        public SGenerate::CopyToOutputDirectory CopyToOutputDirectory
        {
            get { return SGenerate::CopyToOutputDirectory.DoNotCopy; }
        }

        public global::System.Collections.Generic.IEnumerable<string> AutoAddedReferences
        {
            get { return null; }
        }

        public bool FormatGeneratedDocument
        {
            get { return false; }
        }

        public string Header
        {
            get { return null; }
        }

        public string Footer
        {
            get { return null; }
        }

        public string MergeStrategy
        {
            get { return null; }
        }

        public global::System.Collections.Generic.Dictionary<string, string> MergeStrategyParameters
        {
            get { return null; }
        }

        public bool OpenAfterGenerate
        {
            get { return false; }
        }
		
		public bool CheckFirstInCustomCode
        {
            get { return true; }
        }

        #endregion
    }
    
    [SModel::MoldComponent(typeof(SGenerate::ITemplate), MainMold.MoldName, MainMold.ModelName)]
    public partial class BoilerTemplateTemplate : SGenerate::ITemplate
    {
        #region Private Variables

        private SGenerate::SGenerateTemplate template = new global::MainMold.BoilerTemplate();

        #endregion

        #region ITemplate Members
        
        public SGenerate::ISGenerateMold SGenerateMold { get; set; }
        
        public SGenerate::SGenerateTemplate Template
        {
            get { return this.template; }
        }

        public global::System.Type AppliedTo
        {
            get { return typeof(LWC2012Model::IBoiler); }
        }

        public string OutputProjectPattern
        {
            get { return @"WebDocument"; }
        }

        public string OutputPattern
        {
            get { return @"Elements\{Name}.htm"; }
        }

        public SGenerate::IOutputCondition OutputCondition
        {
            get { return null; }
        }

        public SGenerate::BuildAction? BuildAction
        {
            get { return null; }
        }

        public bool Overwrite
        {
            get { return true; }
        }

        public bool OutputToSingleFile
        {
            get { return false; }
        }

        public string CustomTool
        {
            get { return null; }
        }

        public string CustomToolNamespace
        {
            get { return null; }
        }

        public global::System.Type SubItemOf
        {
            get { return null; }
        }

        public global::System.Text.Encoding Encoding
        {
            get { return global::System.Text.Encoding.ASCII; }
        }

        public SGenerate::CopyToOutputDirectory CopyToOutputDirectory
        {
            get { return SGenerate::CopyToOutputDirectory.DoNotCopy; }
        }

        public global::System.Collections.Generic.IEnumerable<string> AutoAddedReferences
        {
            get { return null; }
        }

        public bool FormatGeneratedDocument
        {
            get { return false; }
        }

        public string Header
        {
            get { return null; }
        }

        public string Footer
        {
            get { return null; }
        }

        public string MergeStrategy
        {
            get { return null; }
        }

        public global::System.Collections.Generic.Dictionary<string, string> MergeStrategyParameters
        {
            get { return null; }
        }

        public bool OpenAfterGenerate
        {
            get { return false; }
        }
		
		public bool CheckFirstInCustomCode
        {
            get { return true; }
        }

        #endregion
    }
    
    [SModel::MoldComponent(typeof(SGenerate::ITemplate), MainMold.MoldName, MainMold.ModelName)]
    public partial class BurnerTemplateTemplate : SGenerate::ITemplate
    {
        #region Private Variables

        private SGenerate::SGenerateTemplate template = new global::MainMold.BurnerTemplate();

        #endregion

        #region ITemplate Members
        
        public SGenerate::ISGenerateMold SGenerateMold { get; set; }
        
        public SGenerate::SGenerateTemplate Template
        {
            get { return this.template; }
        }

        public global::System.Type AppliedTo
        {
            get { return typeof(LWC2012Model::IBurner); }
        }

        public string OutputProjectPattern
        {
            get { return @"WebDocument"; }
        }

        public string OutputPattern
        {
            get { return @"Elements\{Name}.htm"; }
        }

        public SGenerate::IOutputCondition OutputCondition
        {
            get { return null; }
        }

        public SGenerate::BuildAction? BuildAction
        {
            get { return null; }
        }

        public bool Overwrite
        {
            get { return true; }
        }

        public bool OutputToSingleFile
        {
            get { return false; }
        }

        public string CustomTool
        {
            get { return null; }
        }

        public string CustomToolNamespace
        {
            get { return null; }
        }

        public global::System.Type SubItemOf
        {
            get { return null; }
        }

        public global::System.Text.Encoding Encoding
        {
            get { return global::System.Text.Encoding.ASCII; }
        }

        public SGenerate::CopyToOutputDirectory CopyToOutputDirectory
        {
            get { return SGenerate::CopyToOutputDirectory.DoNotCopy; }
        }

        public global::System.Collections.Generic.IEnumerable<string> AutoAddedReferences
        {
            get { return null; }
        }

        public bool FormatGeneratedDocument
        {
            get { return false; }
        }

        public string Header
        {
            get { return null; }
        }

        public string Footer
        {
            get { return null; }
        }

        public string MergeStrategy
        {
            get { return null; }
        }

        public global::System.Collections.Generic.Dictionary<string, string> MergeStrategyParameters
        {
            get { return null; }
        }

        public bool OpenAfterGenerate
        {
            get { return false; }
        }
		
		public bool CheckFirstInCustomCode
        {
            get { return true; }
        }

        #endregion
    }
    
    [SModel::MoldComponent(typeof(SGenerate::ITemplate), MainMold.MoldName, MainMold.ModelName)]
    public partial class PumpTemplateTemplate : SGenerate::ITemplate
    {
        #region Private Variables

        private SGenerate::SGenerateTemplate template = new global::MainMold.PumpTemplate();

        #endregion

        #region ITemplate Members
        
        public SGenerate::ISGenerateMold SGenerateMold { get; set; }
        
        public SGenerate::SGenerateTemplate Template
        {
            get { return this.template; }
        }

        public global::System.Type AppliedTo
        {
            get { return typeof(LWC2012Model::IPump); }
        }

        public string OutputProjectPattern
        {
            get { return @"WebDocument"; }
        }

        public string OutputPattern
        {
            get { return @"Elements\{Name}.htm"; }
        }

        public SGenerate::IOutputCondition OutputCondition
        {
            get { return null; }
        }

        public SGenerate::BuildAction? BuildAction
        {
            get { return null; }
        }

        public bool Overwrite
        {
            get { return true; }
        }

        public bool OutputToSingleFile
        {
            get { return false; }
        }

        public string CustomTool
        {
            get { return null; }
        }

        public string CustomToolNamespace
        {
            get { return null; }
        }

        public global::System.Type SubItemOf
        {
            get { return null; }
        }

        public global::System.Text.Encoding Encoding
        {
            get { return global::System.Text.Encoding.ASCII; }
        }

        public SGenerate::CopyToOutputDirectory CopyToOutputDirectory
        {
            get { return SGenerate::CopyToOutputDirectory.DoNotCopy; }
        }

        public global::System.Collections.Generic.IEnumerable<string> AutoAddedReferences
        {
            get { return null; }
        }

        public bool FormatGeneratedDocument
        {
            get { return false; }
        }

        public string Header
        {
            get { return null; }
        }

        public string Footer
        {
            get { return null; }
        }

        public string MergeStrategy
        {
            get { return null; }
        }

        public global::System.Collections.Generic.Dictionary<string, string> MergeStrategyParameters
        {
            get { return null; }
        }

        public bool OpenAfterGenerate
        {
            get { return false; }
        }
		
		public bool CheckFirstInCustomCode
        {
            get { return true; }
        }

        #endregion
    }
    
    [SModel::MoldComponent(typeof(SGenerate::ITemplate), MainMold.MoldName, MainMold.ModelName)]
    public partial class RadiatorTemplateTemplate : SGenerate::ITemplate
    {
        #region Private Variables

        private SGenerate::SGenerateTemplate template = new global::MainMold.RadiatorTemplate();

        #endregion

        #region ITemplate Members
        
        public SGenerate::ISGenerateMold SGenerateMold { get; set; }
        
        public SGenerate::SGenerateTemplate Template
        {
            get { return this.template; }
        }

        public global::System.Type AppliedTo
        {
            get { return typeof(LWC2012Model::IRadiator); }
        }

        public string OutputProjectPattern
        {
            get { return @"WebDocument"; }
        }

        public string OutputPattern
        {
            get { return @"Elements\{Name}.htm"; }
        }

        public SGenerate::IOutputCondition OutputCondition
        {
            get { return null; }
        }

        public SGenerate::BuildAction? BuildAction
        {
            get { return null; }
        }

        public bool Overwrite
        {
            get { return true; }
        }

        public bool OutputToSingleFile
        {
            get { return false; }
        }

        public string CustomTool
        {
            get { return null; }
        }

        public string CustomToolNamespace
        {
            get { return null; }
        }

        public global::System.Type SubItemOf
        {
            get { return null; }
        }

        public global::System.Text.Encoding Encoding
        {
            get { return global::System.Text.Encoding.ASCII; }
        }

        public SGenerate::CopyToOutputDirectory CopyToOutputDirectory
        {
            get { return SGenerate::CopyToOutputDirectory.DoNotCopy; }
        }

        public global::System.Collections.Generic.IEnumerable<string> AutoAddedReferences
        {
            get { return null; }
        }

        public bool FormatGeneratedDocument
        {
            get { return false; }
        }

        public string Header
        {
            get { return null; }
        }

        public string Footer
        {
            get { return null; }
        }

        public string MergeStrategy
        {
            get { return null; }
        }

        public global::System.Collections.Generic.Dictionary<string, string> MergeStrategyParameters
        {
            get { return null; }
        }

        public bool OpenAfterGenerate
        {
            get { return false; }
        }
		
		public bool CheckFirstInCustomCode
        {
            get { return true; }
        }

        #endregion
    }
    
    [SModel::MoldComponent(typeof(SGenerate::ITemplate), MainMold.MoldName, MainMold.ModelName)]
    public partial class SensorTemplateTemplate : SGenerate::ITemplate
    {
        #region Private Variables

        private SGenerate::SGenerateTemplate template = new global::MainMold.SensorTemplate();

        #endregion

        #region ITemplate Members
        
        public SGenerate::ISGenerateMold SGenerateMold { get; set; }
        
        public SGenerate::SGenerateTemplate Template
        {
            get { return this.template; }
        }

        public global::System.Type AppliedTo
        {
            get { return typeof(LWC2012Model::ISensor); }
        }

        public string OutputProjectPattern
        {
            get { return @"WebDocument"; }
        }

        public string OutputPattern
        {
            get { return @"Elements\{Name}.htm"; }
        }

        public SGenerate::IOutputCondition OutputCondition
        {
            get { return null; }
        }

        public SGenerate::BuildAction? BuildAction
        {
            get { return null; }
        }

        public bool Overwrite
        {
            get { return true; }
        }

        public bool OutputToSingleFile
        {
            get { return false; }
        }

        public string CustomTool
        {
            get { return null; }
        }

        public string CustomToolNamespace
        {
            get { return null; }
        }

        public global::System.Type SubItemOf
        {
            get { return null; }
        }

        public global::System.Text.Encoding Encoding
        {
            get { return global::System.Text.Encoding.ASCII; }
        }

        public SGenerate::CopyToOutputDirectory CopyToOutputDirectory
        {
            get { return SGenerate::CopyToOutputDirectory.DoNotCopy; }
        }

        public global::System.Collections.Generic.IEnumerable<string> AutoAddedReferences
        {
            get { return null; }
        }

        public bool FormatGeneratedDocument
        {
            get { return false; }
        }

        public string Header
        {
            get { return null; }
        }

        public string Footer
        {
            get { return null; }
        }

        public string MergeStrategy
        {
            get { return null; }
        }

        public global::System.Collections.Generic.Dictionary<string, string> MergeStrategyParameters
        {
            get { return null; }
        }

        public bool OpenAfterGenerate
        {
            get { return false; }
        }
		
		public bool CheckFirstInCustomCode
        {
            get { return true; }
        }

        #endregion
    }
    
    [SModel::MoldComponent(typeof(SGenerate::ITemplate), MainMold.MoldName, MainMold.ModelName)]
    public partial class SystemEndTemplateTemplate : SGenerate::ITemplate
    {
        #region Private Variables

        private SGenerate::SGenerateTemplate template = new global::MainMold.SystemEndTemplate();

        #endregion

        #region ITemplate Members
        
        public SGenerate::ISGenerateMold SGenerateMold { get; set; }
        
        public SGenerate::SGenerateTemplate Template
        {
            get { return this.template; }
        }

        public global::System.Type AppliedTo
        {
            get { return typeof(LWC2012Model::ISystemEnd); }
        }

        public string OutputProjectPattern
        {
            get { return @"WebDocument"; }
        }

        public string OutputPattern
        {
            get { return @"Elements\{Name}.htm"; }
        }

        public SGenerate::IOutputCondition OutputCondition
        {
            get { return null; }
        }

        public SGenerate::BuildAction? BuildAction
        {
            get { return null; }
        }

        public bool Overwrite
        {
            get { return true; }
        }

        public bool OutputToSingleFile
        {
            get { return false; }
        }

        public string CustomTool
        {
            get { return null; }
        }

        public string CustomToolNamespace
        {
            get { return null; }
        }

        public global::System.Type SubItemOf
        {
            get { return null; }
        }

        public global::System.Text.Encoding Encoding
        {
            get { return global::System.Text.Encoding.ASCII; }
        }

        public SGenerate::CopyToOutputDirectory CopyToOutputDirectory
        {
            get { return SGenerate::CopyToOutputDirectory.DoNotCopy; }
        }

        public global::System.Collections.Generic.IEnumerable<string> AutoAddedReferences
        {
            get { return null; }
        }

        public bool FormatGeneratedDocument
        {
            get { return false; }
        }

        public string Header
        {
            get { return null; }
        }

        public string Footer
        {
            get { return null; }
        }

        public string MergeStrategy
        {
            get { return null; }
        }

        public global::System.Collections.Generic.Dictionary<string, string> MergeStrategyParameters
        {
            get { return null; }
        }

        public bool OpenAfterGenerate
        {
            get { return false; }
        }
		
		public bool CheckFirstInCustomCode
        {
            get { return true; }
        }

        #endregion
    }
    
    [SModel::MoldComponent(typeof(SGenerate::ITemplate), MainMold.MoldName, MainMold.ModelName)]
    public partial class ValveTemplateTemplate : SGenerate::ITemplate
    {
        #region Private Variables

        private SGenerate::SGenerateTemplate template = new global::MainMold.ValveTemplate();

        #endregion

        #region ITemplate Members
        
        public SGenerate::ISGenerateMold SGenerateMold { get; set; }
        
        public SGenerate::SGenerateTemplate Template
        {
            get { return this.template; }
        }

        public global::System.Type AppliedTo
        {
            get { return typeof(LWC2012Model::IValve); }
        }

        public string OutputProjectPattern
        {
            get { return @"WebDocument"; }
        }

        public string OutputPattern
        {
            get { return @"Elements\{Name}.htm"; }
        }

        public SGenerate::IOutputCondition OutputCondition
        {
            get { return null; }
        }

        public SGenerate::BuildAction? BuildAction
        {
            get { return null; }
        }

        public bool Overwrite
        {
            get { return true; }
        }

        public bool OutputToSingleFile
        {
            get { return false; }
        }

        public string CustomTool
        {
            get { return null; }
        }

        public string CustomToolNamespace
        {
            get { return null; }
        }

        public global::System.Type SubItemOf
        {
            get { return null; }
        }

        public global::System.Text.Encoding Encoding
        {
            get { return global::System.Text.Encoding.ASCII; }
        }

        public SGenerate::CopyToOutputDirectory CopyToOutputDirectory
        {
            get { return SGenerate::CopyToOutputDirectory.DoNotCopy; }
        }

        public global::System.Collections.Generic.IEnumerable<string> AutoAddedReferences
        {
            get { return null; }
        }

        public bool FormatGeneratedDocument
        {
            get { return false; }
        }

        public string Header
        {
            get { return null; }
        }

        public string Footer
        {
            get { return null; }
        }

        public string MergeStrategy
        {
            get { return null; }
        }

        public global::System.Collections.Generic.Dictionary<string, string> MergeStrategyParameters
        {
            get { return null; }
        }

        public bool OpenAfterGenerate
        {
            get { return false; }
        }
		
		public bool CheckFirstInCustomCode
        {
            get { return true; }
        }

        #endregion
    }
	public static partial class PropertyExtensions
	{
	}
}
