namespace LWC2012.Model
{
    public enum SensorType
    {
        Pressure = 0,
        Flow = 2,
        Temperature = 3,
    }
}