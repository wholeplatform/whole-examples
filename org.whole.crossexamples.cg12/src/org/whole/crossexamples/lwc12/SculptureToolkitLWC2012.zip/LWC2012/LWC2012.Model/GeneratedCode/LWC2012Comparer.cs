namespace LWC2012.Model
{
    using CommonModel = Modelingsoft.Sculpture.SModel.Common;
        
    public partial class LWC2012Comparer : LWC2012ComparerBase
    {
        #region Constructors
        
        private LWC2012Comparer()
        {
        }
        
        #endregion
        
        #region Public Static Methods
        
        public static CommonModel::IDomainComparer CreateNewInstance()
        {
            return new LWC2012Comparer(); 
        }
        
        #endregion
    }
    
    public abstract class LWC2012ComparerBase : CommonModel::DomainComparer
    {
	    #region DomainComparer Members
        
        protected override void CheckOnModels(CommonModel::IDomainModel leftDomainModel, CommonModel::IDomainModel rightDomainModel)
        {
            if (false == leftDomainModel is LWC2012DomainModel || false == rightDomainModel is LWC2012DomainModel)
            {
                throw new global::System.Exception("The domain models are not valid for compare."); 
            }
        }
        
        #endregion
    }
}
